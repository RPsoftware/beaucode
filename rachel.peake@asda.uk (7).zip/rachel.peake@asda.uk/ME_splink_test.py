# Databricks notebook source
# MAGIC %pip install splink
# MAGIC %pip install --upgrade altair
# MAGIC %pip install --upgrade typing_extensions
# MAGIC
# MAGIC

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

import pyspark.sql.functions as F
from pyspark.sql.types import DecimalType, StringType

#---------------------------- PHONE NBR MATCHING -----------------------------------#

print("loading data with rule 1 applied")
df0 = spark.sql("select * from custanwo.ce.me_sfdata_ssid_match limit 500000") #bring in data already matched by ssid 
#dw0 = spark.read.format("delta").load(self.targetPath2)

df1 = df0.withColumn('customerid', F.col('customerid').cast(DecimalType(20, 0))).withColumn('ssid_match', F.col('customerid'))
#df1 = df1.withColumn('customerid', F.col('customerid').cast(DecimalType(20, 0)))

df2 = df1.filter((F.col('first_name').isNotNull()) & (F.col('last_name').isNotNull()) & (F.col('phone_nbr').isNotNull())).select(F.col('customerid'), F.col('first_name'), F.col('last_name'), F.col('phone_nbr'), F.col('source_system_id')).distinct().repartition("phone_nbr")

#df3 = df2.withColumnsRenamed({'customerid':'ucid_2', 'source_system_id':'source_system_id_2'}).distinct().repartition("phone_nbr")

df_a = df2.toPandas()
df_b = df2.toPandas()


# COMMAND ----------

def prepare_data(data):
                
    return data

dfs = [prepare_data(dataset) for dataset in [df_a, df_b]]

display(dfs[0].head(2))
display(dfs[1].head(2))

# COMMAND ----------

from splink import DuckDBAPI, Linker, SettingsCreator

basic_settings = SettingsCreator(
unique_id_column_name="customerid",
link_type="link_only",
# NB as we are linking one-one, we know the probability that a random pair will be a match
# hence we could set:
# "probability_two_random_records_match": 1/5000,
# however we will not specify this here, as we will use this as a check that
# our estimation procedure returns something sensible
)

linker = Linker(dfs, basic_settings, db_api=DuckDBAPI())


# COMMAND ----------

from splink import DuckDBAPI, block_on
from splink.blocking_analysis import (
    cumulative_comparisons_to_be_scored_from_blocking_rules_chart,
)

blocking_rules = [

    block_on("first_name", "last_name", "phone_nbr")
    
]


db_api = DuckDBAPI()
cumulative_comparisons_to_be_scored_from_blocking_rules_chart(
    table_or_tables=dfs,
    blocking_rules=blocking_rules,
    db_api=db_api,
    link_type="link_only",
    unique_id_column_name="customerid",
    source_dataset_column_name="source_dataset",
)

# COMMAND ----------

import splink.comparison_level_library as cll
import splink.comparison_library as cl


# the simple model only considers a few columns, and only two comparison levels for each
simple_model_settings = SettingsCreator(
    unique_id_column_name="customerid",
    link_type="link_only",
    blocking_rules_to_generate_predictions=blocking_rules,
    comparisons=[
        cl.ExactMatch("first_name").configure(term_frequency_adjustments=True),
        cl.ExactMatch("last_name").configure(term_frequency_adjustments=True),
        cl.ExactMatch("phone_nbr"),
    ],
    retain_intermediate_calculation_columns=True,
)

# the detailed model considers more columns, using the information we saw in the exploratory phase
# we also include further comparison levels to account for typos and other differences
detailed_model_settings = SettingsCreator(
    unique_id_column_name="customerid",
    link_type="link_only",
    blocking_rules_to_generate_predictions=blocking_rules,
    comparisons=[
        cl.ExactMatch("first_name").configure(term_frequency_adjustments=True),
        cl.ExactMatch("last_name").configure(term_frequency_adjustments=True),
        cl.ExactMatch("phone_nbr"),
    ],
    retain_intermediate_calculation_columns=True,
)


linker_simple = Linker(dfs, simple_model_settings, db_api=DuckDBAPI())
linker_detailed = Linker(dfs, detailed_model_settings, db_api=DuckDBAPI())

# COMMAND ----------

deterministic_rules = [
    block_on("source_system_id"),
    block_on("first_name", "last_name", "phone_nbr"),
]

linker_detailed.training.estimate_probability_two_random_records_match(
    deterministic_rules, recall=0.8
)

# COMMAND ----------

df_predict = linker_detailed.inference.deterministic_link()
df_predict.as_pandas_dataframe().head()

# COMMAND ----------

linker_detailed.visualisations.parameter_estimate_comparisons_chart()

# COMMAND ----------

from splink import DuckDBAPI, block_on
from splink.blocking_analysis import (
    cumulative_comparisons_to_be_scored_from_blocking_rules_chart,
)

db_api = DuckDBAPI()
cumulative_comparisons_to_be_scored_from_blocking_rules_chart(
    table_or_tables=dfs,
    blocking_rules=[
        block_on("first_name", "last_name", "phone_nbr"),
    ],
    db_api=db_api,
    link_type="link-only",
)

# COMMAND ----------

from splink.exploratory import profile_columns

#profile_columns(dfs, db_api=DuckDBAPI(), column_expressions=["first_name", "last_name", "phone_nbr"])

# COMMAND ----------

from splink.exploratory import completeness_chart

#completeness_chart(dfs, db_api=DuckDBAPI())