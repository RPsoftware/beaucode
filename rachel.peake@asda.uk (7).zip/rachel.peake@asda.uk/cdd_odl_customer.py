# Databricks notebook source
from pyspark.sql import functions as F

# COMMAND ----------

spark.conf.set("spark.databricks.adaptive.autoOptimize.shuffle.enabled", True)
spark.conf.set("spark.sql.join.preferSortMergeJoin", False)
spark.conf.set("spark.databricks.adaptive.autoBroadcastJoinThreshold", "8589934592")

# COMMAND ----------

class SinglProflCustomer:

    def __init__(self):
        print("Ingesting data ...")
        self.load_data()
        self.dim_cust = (spark.sql("""
            SELECT NULL AS unified_cust_id,
                   bk_crm_customer_id AS crm_id,
                   bk_singl_profl_id AS singl_profl_id,
                   secondary_loginid AS scndry_login_id,
                   account_status,
                   prefix,
                   first_name AS first_nm,
                   last_name AS last_nm,
                   email,
                   is_guest_customer AS guest_ind,
                   registration_date,
                   registration_channel,
                   date_of_birth,
                   NULL AS gdpr_del_ind,
                   suspend_status,
                   suspend_reason,
                   suspend_start_date AS suspend_ts
                   
            FROM coreprod.infomart.dim_customer
            where registration_date between '2024-10-01' and '2024-11-30' """))  # Ensure dim_cust is assigned after loading
          
        #self.dim_cust = self.dim_cust.filter(F.col("loadID") =='1')
        #print("count of loadID1= ",self.dim_cust.count())

        self.cust_agg_attr = spark.sql("""select measure_nm, channel_cd
                            , singl_profl_userid
                            , measure_val
                            , ROW_NUMBER() over (partition by singl_profl_userid, channel_cd order by measure_val desc) rn
                            from coreprod.gb_mb_secured_aggregate_dl_tables.cust_agg_attr where measure_nm = 'LAST_LOGIN_DATE'""")
        
        self.cust_agg_attr = self.cust_agg_attr.filter(F.col("rn") == '1')
        self.cust_agg_attr.createOrReplaceTempView("cust_agg_attr")

        print("cust_agg_attr count = ",self.cust_agg_attr.count())
        #test_agg = self.cust_agg_attr.groupBy("channel_cd") \
                            # .agg(F.countDistinct("channel_cd").alias("distinct_count"))
        #test_agg.display()

        self.loyalty_acct = spark.sql("""select * from coreprod.eagleeye.loyalty_acct""")
        self.loyalty_acct.createOrReplaceTempView("loyalty_acct")
                                         
    def load_data(self):
        self.tables = {
            
            "test_string": "abfss://business@saaslenhdtadmproduks01.dfs.core.windows.net/internal/iddi/ftdw/clbadm/vw_test_account_string",
            "ctc": "abfss://eim@saaslenhdtadmproduks01.dfs.core.windows.net/business/internal/infoMart/facts/fact_customer_terms_condition",
            
        }

        for view_name, path in self.tables.items():
            self.load_table(view_name, path)

        #self.target_table = "abfss://business@saaslenhdtadmproduks01.dfs.core.windows.net/business/internal/ce/odl/cdd_odl_customer"

    def load_table(self, view_name, path):
        try:
            df = spark.read.format("delta").load(path)
            df.createOrReplaceTempView(view_name)
            return df
            
        except Exception as e:
            print(f"No data ingested for {view_name}: {e}")

    def run(self):
        print("** Execution Start **")
        self.process_test_data()
        self.processData()
        df_output2 = self.joinData()
        print(df_output2.count())
        
        df_output2 = df_output2.withColumn("contactable_first_nm", F.when(F.col("first_nm").isNotNull(), F.initcap(F.col("first_nm"))))

        df_output2.select('crm_id','singl_profl_id','unified_cust_id','wallet_id','scndry_login_id'
                        ,'account_status','prefix','first_nm','contactable_first_nm','last_nm','email','guest_ind','registration_date','registration_channel','date_of_birth','gdpr_del_ind','suspend_status'
                        ,'suspend_reason','suspend_ts','tnc_accepted_at_grocery','tnc_accepted_at_sng'
                        ,'tnc_accepted_at_sng_kiosk','tnc_accepted_at_sng_mobile','tnc_accepted_at_george'
                        ,'tnc_accepted_at_gift_card','tnc_accepted_at_loyalty','tnc_accepted_at_credit_card'
                        ,'tnc_accepted_at_asda_mobile','last_login_at_grocery','last_login_at_sng_kiosk'
                        ,'last_login_at_sng_mobile','last_login_at_george','last_login_at_asda','last_login_at_gift_card','last_login_at_loyalty','test_account_ind').distinct()
        
        #df_output.printSchema()
        
        df_output2.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable("custanwo.ce.cdd_odl_customer")
        print("** Execution End **")

#----------------------------------------------------------------------------------------------------------------------------------------------------------------------
# FUNCTIONS
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------

    def process_test_data(self):
        df_test_email = self.get_test_data('EMAIL').alias("email_table")
        df_test_fn = self.get_test_data('FIRST_NM').alias("first_name_table")

        self.df_flagged = self.dim_cust.alias("cust") \
            .join(df_test_email, F.col("cust.email") == F.col("email_table.string"), 'left') \
            .join(df_test_fn, F.col("cust.first_nm") == F.col("first_name_table.string"), 'left') \
            .select("cust.*", 
                F.when(F.col("email_table.string").isNotNull() | F.col("first_name_table.string").isNotNull(), 'Y').otherwise('N').alias('test_account_ind')
            )

        self.df_maxflagged = self.df_flagged.groupBy("singl_profl_id") \
            .agg(F.max("test_account_ind").alias("test_account_ind")) \
            .distinct()

        self.df_maxflagged = self.df_maxflagged.withColumnsRenamed({"singl_profl_id": "singl_profl_id_new"})
        #self.dim_cust.printSchema()

        self.dim_cust_clean = self.df_maxflagged.join(
            self.dim_cust.alias("cust"),
            F.col("singl_profl_id_new") == F.col("cust.singl_profl_id"), 
            'inner'
        ).select("cust.*", "test_account_ind")
        print("test data processed: ", self.dim_cust_clean.count())

    def get_test_data(self, field):
        return spark.sql(f"SELECT field, string FROM test_string WHERE field='{field}'")

    def processData(self):
        df_distinct_ids = self.dim_cust_clean.select("singl_profl_id").distinct() #filter source tables by distinct ids
        df_distinct_ids.createOrReplaceTempView("distinct_ids")

        self.df_ctc = spark.sql("""
            SELECT distinct a.bk_singl_profl_id, lastmodifieddate, servicename__c
            FROM ctc a
            JOIN (SELECT DISTINCT singl_profl_id FROM distinct_ids) b
            ON a.bk_singl_profl_id = b.singl_profl_id
        """)
        #self.df_ctc.cache()
        #print("count of ctc df: ",self.df_ctc.count())

        self.df_loyalty_acct = spark.sql("""
            SELECT distinct wallet_id, a.singl_profl_id AS user_loyalty_singl_profl_id  
            FROM loyalty_acct a
            JOIN (SELECT DISTINCT singl_profl_id FROM distinct_ids) b
            ON a.singl_profl_id = b.singl_profl_id
        """)
        #self.df_loyalty_acct.cache()
        #print("count of loyalty acct df: ", self.df_loyalty_acct.count())
 
        self.df_aggr = spark.sql(""" select measure_nm
                                 , channel_cd
                                 , singl_profl_userid
                                 , measure_val 
                                 from cust_agg_attr a
                            INNER JOIN distinct_ids b
                            ON a.singl_profl_userid = b.singl_profl_id
        """)
        
        #print("count of cust aggr df: ",self.df_aggr.count())
        
        service_names = ["Grocery", "SnG KIOSK", "SnG MOBILE", "GEORGE", "Gift Card", 
                         "Asda Rewards", "Credit Card", "Asda Mobile"]
        self.df_tnc = {}

        for service_name in service_names:
            self.df_tnc[service_name] = self.df_ctc.filter(F.col("servicename__c") == service_name) \
                .select(F.col('bk_singl_profl_id').alias(f'tnc_{service_name.lower().replace(" ", "_")}_userid'),
                        F.col('lastmodifieddate').alias(f'tnc_accepted_at_{service_name.lower().replace(" ", "_")}'))
            
            self.df_tnc[service_name] = self.df_tnc[service_name].join(df_distinct_ids, F.col("singl_profl_id") == F.col((f'tnc_{service_name.lower().replace(" ", "_")}_userid')), how="INNER").drop(df_distinct_ids.singl_profl_id)
            #print("count of ", [service_name]," df: ", self.df_tnc[service_name].count())

        channels = ["GROCERY", "SNGKIOSK", "SNGMOBILE", "GEORGE", "ASDA", "GIFTCARDS", "LOYALTY"]

        self.df_login = {}

        for channel in channels:
            self.df_login[channel] = self.df_aggr.filter(
                (F.upper(F.col("channel_cd")) == (channel).upper())) \
                .select(F.col('singl_profl_userid').alias(f'tnc_login_{channel.lower()}_userid'),
                        F.col('measure_val').alias(f'last_login_at_{channel.lower()}'))
            #print("count of ",[channel]," login df: ", self.df_login[channel].count())

        print("data processed...joining data")

    def joinData(self):
        df_output = self.dim_cust_clean.distinct()
        print("schema before joins is : ", df_output.printSchema())
              
        for key, df in self.df_tnc.items():
            df_output = df_output.join(df.alias(key), 
                df_output.singl_profl_id == F.col(f"{key}.tnc_{key.lower().replace(' ', '_')}_userid"), 
                how="left"
            ).drop(f"{key}.tnc_{key.lower().replace(' ', '_')}_userid")

        print("schema after tnc joins is : ", df_output.printSchema())

        for key, df in self.df_login.items():
            print("joining login df: ", key)
            df_output = df_output.join(df.alias(key), 
                df_output.singl_profl_id == F.col(f"{key}.tnc_login_{key.lower()}_userid"), 
                how="left"
            ).drop(f"{key}.tnc_login_{key.lower()}_userid")
        print("schema after login joins is : ", df_output.printSchema())

        df_output1 = df_output.join(self.df_loyalty_acct.alias("loyalty"), 
            df_output.singl_profl_id == F.col("loyalty.user_loyalty_singl_profl_id"), 
            how="left"
        ).drop("loyalty.user_loyalty_singl_profl_id")
        #df_output.cache()
        #print("data joined...", df_output3.count())
        df_output1.printSchema()

        
        df_output2 = df_output1.withColumn("tnc_accepted_at_sng",
            F.when(F.col("tnc_accepted_at_sng_kiosk") < F.col("tnc_accepted_at_sng_mobile"),
                    F.col("tnc_accepted_at_sng_kiosk")).otherwise(F.col("tnc_accepted_at_sng_mobile"))
        )
        df_output2 = df_output2.withColumnsRenamed({"tnc_accepted_at_asda_rewards": "tnc_accepted_at_loyalty", "last_login_at_sngkiosk": "last_login_at_sng_kiosk", "last_login_at_sngmobile": "last_login_at_sng_mobile", "last_login_at_giftcards":"last_login_at_gift_card"})

        return df_output2



# COMMAND ----------

aa = SinglProflCustomer()
aa.run()