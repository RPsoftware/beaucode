# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, ArrayType, IntegerType
import pyspark.sql.functions as F


# Sample data
data = [
    ("2023", "source1"),
    ("2023", "source2"),
    ("2023", "source3"),
    ("2024", "source1"),
    ("2024", "source4"),
    ("2024", "source5"),
    ("2024", "source6"),
    ("2025", "source1"),
]

# Create a DataFrame
schema = StructType([
    StructField("pn_ucid", StringType(), True),
    StructField("source_system_id", StringType(), True),
])

df9 = spark.createDataFrame(data, schema)

# Create array to hold the list of matches
df10 = df9.groupBy('pn_ucid').agg(F.collect_set('source_system_id').alias('ssid')).distinct()
df10.display()

# Define the merge function
def merge_arrays_with_common_elements(arrays):
    merged = []  # To hold the merged arrays
    visited = [False] * len(arrays)  # Track which arrays have been merged

    while True:
        current_merge_found = False  # Track if we found any merges in this iteration
        current_merge = []  # Clear current_merge for each iteration
        
        for i in range(len(arrays)):
            if visited[i]:
                continue  # Skip already merged arrays
            
            # Start a new merged array with the current array as a set to ensure uniqueness
            temp_merge = set(arrays[i])
            visited[i] = True
            
            # Check against all other arrays to find common elements
            for j in range(i + 1, len(arrays)):
                if not visited[j] and (temp_merge & set(arrays[j])):  # Check for common elements
                    temp_merge.update(arrays[j])  # Merge arrays
                    visited[j] = True  # Mark as merged
                    current_merge_found = True  # Found at least one merge

            # Add the merged array to current_merge
            current_merge.append(list(temp_merge))

        # If no merges were found in this iteration, break the loop
        if not current_merge_found:
            print("No more common elements found. Merging complete.")
            break
        
        # Update arrays for the next iteration
        arrays = current_merge  # Use the newly merged arrays

    return arrays

def assign_unique_ids(merged_arrays):
    # Assign a unique ID to each merged array
    return [(idx, array) for idx, array in enumerate(merged_arrays)]

# List to hold all merged results
all_merged_results = []

# Get the total number of rows in df10
total_rows = df10.count()

# Define the chunk size
chunk_size = 3  # Adjust as needed for testing

# Counter for processed chunks
processed_chunks = 0
total_chunks = (total_rows + chunk_size - 1) // chunk_size  # Calculate total chunks

# Loop through the DataFrame in chunks
for offset in range(0, total_rows, chunk_size):
    chunk = df10.limit(chunk_size).offset(offset)  # This requires a proper DataFrame operation
    
    # Extract the arrays for merging
    chunk_arrays = [row['ssid'] for row in chunk.select("ssid").collect()]

    # Print which ssid arrays are being merged
    print(f"Processing chunk {processed_chunks + 1}/{total_chunks}: merging {len(chunk_arrays)} arrays.")

    # Call the function to merge arrays for this chunk
    merged_chunk = merge_arrays_with_common_elements(chunk_arrays)

    # Collect the results
    all_merged_results.extend(merged_chunk)

    # Update the processed chunks counter
    processed_chunks += 1

# Assign unique IDs to each merged array
merged_with_ids = assign_unique_ids(all_merged_results)

# Define schema for DataFrame
schema = StructType([
    StructField("ID", IntegerType(), True),
    StructField("ssid", ArrayType(StringType()), True),
])

# Create DataFrame from merged data
df_gid1 = spark.createDataFrame(data=merged_with_ids, schema=schema)

# Print the maximum size of the ssid in the latest array
print("How many ssids in the latest array?")
df_gid1.select(F.max(F.size(F.col("ssid")))).show()

# Show the final merged arrays
df_gid1.show(truncate=False)




# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

#Install additional libraries
%pip install pycryptodome

# COMMAND ----------

# Importing necessary libraries
import base64
from Crypto.Cipher import AES
import re
import os
import pyspark.sql.functions as F
from Crypto.Util.Padding import pad
from pyspark.sql.types import StructType, StructField, IntegerType, ArrayType, StringType, DecimalType, LongType, DateType
from pyspark.sql.window import Window


# COMMAND ----------

def encrypt_values (clear_text, master_key):
    if clear_text:
        cipher = AES.new(bytes(master_key, 'ascii'), AES.MODE_ECB)
        cipher_text = cipher.encrypt(pad(str(clear_text).encode("UTF-8"), AES.block_size))
        textBase64 = base64.b64encode(cipher_text)
        textBase64P = textBase64.decode('UTF-8')
        return textBase64P
    return clear_text

# COMMAND ----------

# DBTITLE 1,create history to perform matching on


class matchingEngine:
    
    def __init__(self): 

        #spark settings 
        spark.conf.set("spark.sql.parquet.enableVectorizedReader","false") #Stopping the automatic conversion in double, decimal datatype to Binary
        
        #source path for data in rdl storage (stg layer)
        self.sourcePath = "/mnt/stg/business/"
        
        #------------------------------ BRING IN SOURCE DATA FROM STG LAYER ----------------------------------#
        
        try: #bring in cust data
                self.cust = spark.read.format("delta").load(self.sourcePath + "confidential/iddi/rdl/gb_customer_secured_dl_tables/cust")
        except:
                print("no data found for [cust], check source location")

        try: #bring in cust_card data
                self.custCard =  spark.read.format("delta").load(self.sourcePath + "confidential/iddi/rdl/gb_customer_secured_dl_tables/cust_card/")
        except:
                print("no data found for [cust_card], check source location")

        try: #bring in store_visit_tender data 
                self.stor =  spark.read.format("delta").load(self.sourcePath + "confidential/iddi/rdl/gb_mb_store_secured_dl_tables/store_visit_tender/")
        except:
                print("no data found for [stor], check source location")

        try: #bring in cust_cntct
                self.custCntct =  spark.read.format("delta").load(self.sourcePath + "confidential/iddi/rdl/gb_customer_secured_dl_tables/cust_cntct")
        except:
                print("no data found for [cust_cntct], check source location")
        
        try: #bring in cust_addr   
                self.custAddr =  spark.read.format("delta").load(self.sourcePath + "confidential/iddi/rdl/gb_customer_secured_dl_tables/cust_addr/")
        except:
                print("no data found for [cust_addr], check source location")
        
        try: #bring in cust_addr
                self.transaction_ids =  spark.read.format("delta").load("/mnt/enh/business/internal/iddi/rdl/gb_customer_data_domain_odl/cdd_odl_transaction_ids") 
        except:
                print("no data found for [transaction_ids], check source location")

        try: #bring in cust_addr
                self.dim_customer =  spark.read.format("delta").load("/mnt/eim/business/internal/infoMart/dimensions/dim_customer/")
        except:
                print("no data found for [dim_customer], check source location")

        try: #bring in xref to token id mapping table
                self.mapping = spark.read.format("delta").load(self.sourcePath + "internal/iddi/rdl/gb_mb_store_secured_dl_tables/xref_surrogate_token")
        except:
                print("no data found for [xref_surrogate_token] , check source location")
 
        
        #---------------------- SET VARIABLES --------------------------------------#

        self.columns_to_check = ['customerid', 'source_system_id', 'title', 'first_name', 'middle_name', 'last_name', 'email_id', 'phone_nbr', 'pihash', 'xref', 'token_id', 'guest_order_ind', 'billing_first_name', 'billing_last_name', 'billing_address1', 'billing_address2', 'billing_address3', 'billing_address4', 'billing_address5', 'billing_address6', 'billing_city', 'billing_county', 'billing_zip_Cd', 'billing_state', 'billing_country', 'billing_address', 'latitude', 'longitude', 'blacklist', 'cbb_seen', 'version', 'source', 'ingestts', 
                                 ]

        self.email_id_column_patterns = ['%@asda1%', '%[_]automation%', 'createnew%', 'mobile_auto%', 'rishi2019%', 'qa[_]%', '%qaprod%', '%@devmail%', '%@asda1%', '%@asda2%', '%@user.com', '%sngtest%', '%@test.com', '%@jmeter.com', '%@keynote.doo', '%@sptest.com', '%@spother.com', '%sng.com', '%asif.com', '%test4.com', '%tnccheck%', '%prodcheck%', '%bsahoo%', '%asda.com', '%asdatest.com', '%keynote%', '%checkoutopt%', 'dpmigrationtest%', '%qa_spuser%', '%scanandgoqbust', '%perftest.com', '%asdatest%'
                                ]
        self.first_name_column_patterns = ['Automation%','TestFN']

        self.address_column_patterns = ['%dummy%']

        #set dates
        #self.max_date = (F.date_sub(F.current_date(), 1))
        #self.min_date = (F.date_sub(self.max_date, 1096))
        #print(self.min_date, '  ',self.max_date)

        #set env variables
        self.env = os.getenv('env')
        self.loc = 'uks'
        self.instance = '01'

        ## Key Vault variables
        self.dbScope = 'kv-sa-lnd-{}-{}-{}'.format(self.env,self.loc,self.instance)
       
        #encryption variables
        self.encrypt_columns = ['pihash']
 
        ## Target table variables 
        self.targetPath = "/mnt/eim/business/internal/ce/raw/cdd_raw_unified_customer" # final table output 
        #self.targetPath1 = "/mnt/eim/business/internal/ce/raw/stg1_uc" # rule 0
        self.targetPath1 = "abfss://eim@saaslenhdtadmproduks01.dfs.core.windows.net/business/internal/ce/raw/stg1_uc"
        self.targetPath2 = "/mnt/eim/business/internal/ce/raw/stg2_uc" # rule 1
        self.targetPath3 = "/mnt/eim/business/internal/ce/raw/stg3_uc" # rule 2
        self.targetPath4 = "/mnt/eim/business/internal/ce/raw/stg4_uc" # rule 3
        self.targetPath5 = "/mnt/eim/business/internal/ce/raw/stg5_uc" # join between token ids
        self.targetPath6 = "/mnt/eim/business/internal/ce/raw/stg6_uc" # join to spid 
        self.targetPath7 = "/mnt/eim/business/internal/ce/raw/stg7_uc" # second join to spid 
        self.targetPathLookup = "/mnt/eim/business/internal/ce/raw/lookup_table" #


        #--------------------------- FUNCTIONS --------------------------#
 
#Function to replace blank values with null
    def replace_blank_with_null(self,df,columns_to_check):
        new_df = df.select([F.when(F.col(column) == '', None).otherwise(F.col(column)).alias(column) for column in columns_to_check])
        return new_df

#Function to filter out the test data before matching
    def filter_test_data(self,df, email_column,email_column_patterns,first_name_column,first_name_column_patterns, address_column, address_column_patterns):
        remaining_df = df
        email_condition = df[email_column].rlike('|'.join(email_column_patterns))
        first_name_condition = df[first_name_column].rlike('|'.join(first_name_column_patterns))
        address_condition = df[address_column].rlike('|'.join(address_column_patterns))
        matched_data = df.filter(email_condition | first_name_condition | address_condition)
        remaining_df = remaining_df.subtract(matched_data)
        return matched_data, remaining_df

#Function to convert sql wildcard to python regular expression for removing test data since we are using python
    def sql_list_to_regex_list(self,sql_list):
        regex_exp_list = [re.sub(r"%",".*",expr) for expr in sql_list]
        regex_exp_list = [re.sub(r"_",".",expr) for expr in regex_exp_list]
        return regex_exp_list   

#-----------------------------------------------------------------------------------#
#-------------------------------------- MAIN ---------------------------------------#
#-----------------------------------------------------------------------------------#

    def run(self):
        '''    
        # apply filters to data
        #self.stor.createOrReplaceTempView('stor')
        #self.stor = spark.sql("""select distinct trim(acct_nbr) as acct_nbr, max(upd_ts) as upd_ts 
                              from stor where tndr_type_cd = '8' and visit_dt >= {} 
                              group by acct_nbr """.format(self.min_date))
        
        #self.stor = self.replace_blank_with_null(self.stor,self.stor.columns)

        self.custCard.createOrReplaceTempView("custCard")
        #self.custCard = spark.sql("""select distinct trim(pymt_token_txt) as pymt_token_txt, ref_id, singl_profl_id
                                  from custCard 
                                  where gdpr_del_ind = 0 and cust_del_ind = 0 """).withColumn('ref_id', F.col('ref_id').cast(LongType()))       

        #self.custCard = self.replace_blank_with_null(self.custCard,self.custCard.columns)

        #create latest temp views for each table to use in SPARK SQL Query 
        #self.cust.createOrReplaceTempView("cust")
        #self.custCard.createOrReplaceTempView("custCard")
        #self.stor.createOrReplaceTempView('stor')
        #self.custCntct.createOrReplaceTempView("custCntct")
        #self.custAddr.createOrReplaceTempView("custAddr")
        #self.mapping.createOrReplaceTempView("xtmap")
        self.dim_customer.createOrReplaceTempView("dim_cust")

        #spark sql joins to create base data 
        sp=(select '' as customerid
                        ,dim_cust.bk_crm_customer_id as crm_customer_id
                        ,dim_cust.bk_singl_profl_id as source_system_id 
                        ,lower(trim(dim_cust.prefix)) as title
                        #,lower(dim_custfirst_name) as first_name 
                        ,dim_cust.middle_name as middle_name
                        ,lower(dim_cust.last_name) As last_name 
                        ,lower(trim(dim_cust.email)) as email_id 
                        ,COALESCE(trim(cntct.cntct_nm)
                        ,trim(dim_cust.secondary_loginid)) as phone_nbr
                        ,trim(cr.pymt_token_txt) as pihash
                        ,trim(cr.ref_id) as xref
                        ,cr.surrogate_token_id as token_id
                        ,dim_cust.is_guest_customer as guest_order_ind
                        ,lower(trim(adr.first_nm)) as billing_first_name,lower(trim(adr.last_nm)) as billing_last_name 
                        ,lower(trim(adr.addr_line_1_txt)) as billing_address1
                        ,lower(trim(adr.addr_line_2_txt)) as billing_address2 
                        ,lower(trim(adr.addr_line_3_txt)) as  billing_address3
                        ,'' as billing_address4
                        ,'' as billing_address5
                        ,'' as billing_address6 
                        ,lower(trim(adr.city_nm)) as billing_city
                        ,'' as billing_county
                        ,lower(trim(adr.post_cd)) as billing_zip_Cd
                        ,lower(trim(adr.st_nm)) as billing_state
                        ,lower(trim(adr.cntry_cd)) as billing_country
                        ,lower(trim(adr.fmt_addr_txt)) as billing_address
                        ,adr.lat_dgr as latitude
                        ,adr.long_dgr as longitude
                        ,'' as blacklist
                        ,'' as cbb_seen
                        ,'' as version
                        ,'sf' as source
                        ,IFNULL((DATE_FORMAT(dim_cust.created_date,'yyyyMMdd')),999999) as ingestts 
                from (select bk_crm_customer_id,bk_singl_profl_id,prefix,first_name,last_name,middle_name,email,is_guest_customer,created_date, secondary_loginid
                        from dim_cust where lower(active_record) = 'y' and bk_crm_customer_id !='-999999999' ) dim_cust 
                left join (select cntct_nm,singl_profl_id 
                        from custCntct 
                        where cntct_type_nm ='PHONE' and gdpr_del_ind=0 and cust_del_ind=0) cntct 
                on dim_cust.bk_singl_profl_id=cntct.singl_profl_id 
                left join (select singl_profl_id,pymt_token_txt,ref_id, surrogate_token_id 
                        from custCard left join (select distinct xref_token_id, surrogate_token_id from xtmap) map on custCard.ref_id = map.xref_token_id ) cr 
                on dim_cust.bk_singl_profl_id=cr.singl_profl_id 
                left join (select singl_profl_id, first_nm, last_nm, addr_line_1_txt, addr_line_2_txt, addr_line_3_txt, city_nm, post_cd, st_nm, cntry_cd, fmt_addr_txt, lat_dgr, long_dgr 
                        from custAddr  
                        where gdpr_del_ind=0 and cust_del_ind=0 and (addr_usag_type_nm IS NULL or addr_usag_type_nm='shipTo')) adr
                on dim_cust.bk_singl_profl_id=adr.singl_profl_id )
      
        sp = spark.sql(sp).dropDuplicates()

        #create store data df
        storeExtract=(select distinct '' as customerid
                                ,'' as crm_customer_id
                                ,case when map.surrogate_token_id is not null then map.surrogate_token_id else acct_nbr end as source_system_id
                                ,null as title
                                ,null as first_name
                                ,null as middle_name
                                ,null As last_name
                                ,null as email_id
                                ,null as phone_nbr
                                ,null as pihash
                                ,acct_nbr as xref
                                ,map.surrogate_token_id as token_id
                                ,null as guest_order_ind
                                ,null as billing_first_name
                                ,null as billing_last_name
                                ,null as billing_address1
                                ,null as billing_address2
                                ,null as billing_address3
                                ,null as billing_address4
                                ,null as billing_address5
                                ,null as billing_address6
                                ,null as billing_city
                                ,null as billing_county
                                ,null as billing_zip_Cd
                                ,null as billing_state
                                ,null as billing_country
                                ,null as billing_address
                                ,null as latitude
                                ,null as longitude
                                ,null as blacklist
                                ,null as cbb_seen
                                ,null as version
                                ,'store' as source
                                ,IFNULL((DATE_FORMAT(stor.upd_ts, 'yyyyMMdd')),999999) as partkey 
                        from (select acct_nbr, max(upd_ts) as upd_ts
                                from stor group by acct_nbr 
                                ) stor left join (select distinct xref_token_id, surrogate_token_id from xtmap) map on stor.acct_nbr = map.xref_token_id
                         )
        
        storeExtract = spark.sql(storeExtract).dropDuplicates()
        
        unionDF = sp.union(storeExtract)

        #Replacing blank values with null
        df_intData_trans = self.replace_blank_with_null(unionDF,unionDF.columns)

        #remove any rows which wont match to ucid 
        df_intData_trans = df_intData_trans.filter(F.col('source_system_id').isNotNull() | F.col('xref').isNotNull() | F.col('token_id').isNotNull()| F.col('email_id').isNotNull()| F.col('phone_nbr').isNotNull()| F.col('first_name').isNotNull()| F.col('last_name').isNotNull())
        
        #test data removal to get the data frame free of unwanted test data
        email_id_column_patterns_formatted = self.sql_list_to_regex_list(self.email_id_column_patterns)
        first_name_column_patterns_formatted = self.sql_list_to_regex_list(self.first_name_column_patterns)
        address_column_patterns_formatted = self.sql_list_to_regex_list(self.address_column_patterns)
        
        test_data_frame, cleanDF = self.filter_test_data(df_intData_trans,'email_id',email_id_column_patterns_formatted,'first_name', first_name_column_patterns_formatted, 'billing_address1', address_column_patterns_formatted)
        
        #replacing the leading 0's in xref for a proper match / Changing Datatype of UCID from String to Long 
        df_intData = (cleanDF.withColumn('xref',F.regexp_replace(F.col('xref'),'^0+',''))
                      .withColumn("customerid",F.col("customerid").cast("long"))
                      )
        
        #------------------------------ Applying axiomatic rules -----------------------------------------#        
        print('Applying RULE 0 to the data frame to create unique UCID for each record')

        # day 0 assign unique customerid by subtracting row number from max_id, this gives unique number to all records 
        window_spec_ordering = Window.orderBy("source")
        df = df_intData.withColumn("row_number",F.row_number().over(window_spec_ordering))
        max_id = "10000000000000000000"
        max_id = (F.lit(max_id)).cast(DecimalType(20, 0))
        df = df.withColumn("customerid",max_id-F.col("row_number").cast(DecimalType(20, 0))).drop("row_number")

        df.write.mode("overwrite").option("overwriteSchema", "true").format("delta").save(self.targetPath1) # first base query written out and further rules should be run based on this data 
         
        '''  
aa = matchingEngine()
aa.run()

# COMMAND ----------

# MAGIC %md
# MAGIC Carry on matching rules from here ...

# COMMAND ----------

targetPath1 = "abfss://eim@saaslenhdtadmproduks01.dfs.core.windows.net/business/internal/ce/raw/stg1_uc"

# COMMAND ----------

df = spark.read.format("delta").load(targetPath1)
df.display(500)
#--file of data with a unique identifier for each record--#
#--the data needs to be matched on any of the following criteria
#--[source_system_id] or "ssid", [first_name, last_name, phone_nbr], [first_name, last_name, billing_address], [token_id],[xref]
#--if match is made, all records with same ssid will have the same uniqueID (customerid or "ucid"), i.e. if ssid 1 & 2 are matched on token_id, all rows with ssid 1 and ssid 2 need to have the same ucid, if ssid 1 has already matched with ssid 3, ssid 1, 2 & 3 will all need the same ucid, and if ssid 2 has already matched with ssid 4, ssid 1, 2, 3 & 4 will all need the same ucid, and if ssid 3 has already matched with ssid 5, ssid 1, 2, 3, 4 & 5 will all need the same ucid .. and so on 
#--if no match, then assign a new unique customerid for the SSID  


# COMMAND ----------

#-- Issue with any method tried is that eventually we get a split in ssid with an ssid having 2 different customerids or "ucids", or a group not being matched under the same ID anymore even though when you investigate you can see it should be matched .. with each new rule that I run it seems to unmatch some data whilst matching other data. It's difficult to follow it through to see why it's become unmatched.
#-- have tried grouping and partitioning, selecting either min(), max(), first(), last() values of customerid then putting into a reference table, then fetching the customerid from the ref table, but still appearig to get splits when the rows should be matched 
#-- have tried joining and joining and joining but very time consuming and estimate about 10 bill comparisons happening in history data 
#-- need a new approach .....??? 
#--or for someone with a fresh eye to tell me where I'm doing something stupid!
#-- considering whether looking at each group of ssid's and comparing with data already matched - like row reconciliation rather than grouping and re-grouping?

# COMMAND ----------


#---------------------------- SSID MATCHING------------------------------------#

#from here, split data into 3 parts 
#source = sf and token_id is null
#source = sf and token_id is not null 
#source = store 

print("loading base data")
df = spark.read.format("delta").load(targetPath1)
df_sf_nullToken = df.filter((F.col('source') == 'sf') & (F.col('token_id').isNull()))

print("running rule 1: group by ssid and assign min(customerid)... ")
df = df_sf_nullToken.withColumn("original_ucid", F.col("customerid"))
window_spec_1 = Window.partitionBy("source_system_id").orderBy(F.col('customerid').asc()) 
df_w0 = df.withColumn("min_customerid",F.min("customerid").over(window_spec_1))

df_w0 = df_w0.withColumn("customerid", F.when(F.col('source_system_id').isNotNull(),F.col("min_customerid")).otherwise(F.col('customerid'))).drop("min_customerid")

#df_w0.write.mode("overwrite").option("overwriteSchema", "true").format("delta").save(self.targetPath2) # Rule 1
df_w0.write.option("overwriteSchema", "true").saveAsTable("`custanwo`.`ce`.`me_sfdata_ssid_match`",mode="overwrite")
##at this point we have a list of records where a ucid has been assigned based on ssid ##

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import explode, col

def merge_arrays_with_common_elements(arrays):
    merged = []  # To hold the merged arrays
    visited = [False] * len(arrays)  # Track which arrays have been merged

    while True:  # Keep running until no more merges are found
        for i in range(len(arrays)):
            if visited[i]:
                continue  # Skip already merged arrays
            
            # Start a new merged array with the current array
            current_merge = set(arrays[i])
            visited[i] = True
            
            # Check against all other arrays to find common elements
            for j in range(i + 1, len(arrays)):
                if not visited[j] and (current_merge & set(arrays[j])):  # Check for common elements
                    current_merge.update(arrays[j])  # Merge arrays
                    visited[j] = True  # Mark as merged

            merged.append(list(current_merge))  # Add the merged array to the result

        # Create a DataFrame from merged arrays (ensure they are treated as arrays)
        df = spark.createDataFrame([(array,) for array in merged], ["arrays"])
        
        # Explode the arrays into individual rows
        exploded_df = df.select(explode(col("arrays")).alias("array_value"))

        # Group by value and count occurrences
        count_df = exploded_df.groupBy("array_value").count()

        # Filter values that appear more than once
        result_df = count_df.filter(col("count") > 1)

        # Check if result_df is empty
        if result_df.count() == 0:  # Using count() to check for emptiness
            print("No values appear in more than one array.")
            break  # Exit the loop if no more common elements are found
        else:
            # If not empty, reset for the next iteration
            arrays = merged  # Use the newly merged arrays
            merged = []  # Clear merged to start over
            visited = [False] * len(arrays)  # Reset visited

    return merged

def assign_unique_ids(merged_arrays):
    # Assign a unique ID to each merged array
    return [(idx, array) for idx, array in enumerate(merged_arrays)]

# Example usage
if __name__ == "__main__":
    arrays = [
        ["ssid1", "pn2", "addr10", "token3"],
        ["ssid1", "pn121", "addr32", "token4"],
        ["ssid132", "pn1", "addr32", "token32"],
    ]

    # Merge arrays
    merged_arrays = merge_arrays_with_common_elements(arrays)
    
    # Assign unique IDs to each merged array
    merged_with_ids = assign_unique_ids(merged_arrays)

    # Print the results
    for unique_id, array in merged_with_ids:
        print(f"ID: {unique_id}, Merged Array: {array}")
    



# COMMAND ----------

# Get total size in memory
df = spark.read.format("delta").load(targetPath1)
import pyspark.sql.functions as F

# Create a UDF to calculate row size
def row_size_udf(*cols):
    return sum(len(str(col)) if col is not None else 0 for col in cols)

# Register UDF
row_size_udf = F.udf(row_size_udf, IntegerType())

# Add a new column with the size of each row
df_with_size = df.withColumn("row_size", row_size_udf(*df.columns))

# Show the DataFrame with row sizes
df_with_size.show()

# Calculate average row size
average_row_size = df_with_size.agg(F.avg("row_size")).first()[0]
print(f"Average row size: {average_row_size} bytes")


# COMMAND ----------

 dbutils.library.restartPython() 

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql import Row
from pyspark.sql.window import Window
from pyspark.sql.types import StructType, StructField, ArrayType, StringType



# Sample data
data = [
    Row(ssid_ucid="UCID112", phone_ucid="UCID132", adr_ucid="UCID31", token_ucid="UCID54"),
    Row(ssid_ucid="UCID2", phone_ucid="UCID5", adr_ucid="UCID6", token_ucid="UCID7"),
    Row(ssid_ucid="UCID3", phone_ucid="UCID8", adr_ucid="UCID1", token_ucid="UCID9"),
    Row(ssid_ucid="UCID4", phone_ucid="UCID5", adr_ucid="UCID10", token_ucid="UCID11"),
    Row(ssid_ucid="UCID6", phone_ucid="UCID2", adr_ucid="UCID8", token_ucid="UCID12"),
    Row(ssid_ucid="UCID31", phone_ucid="UCID3", adr_ucid="UCID9", token_ucid="UCID10")
]

# Create a DataFrame
df = spark.createDataFrame(data)

# Create an array column from the _ucid values
df_with_array = df.withColumn("ucid_array", F.array_distinct(F.array(
    df.ssid_ucid, 
    df.phone_ucid, 
    df.adr_ucid, 
    df.token_ucid
)))

# Function to merge arrays based on exact matching UCID values
def merge_arrays(arrays):
    merged = []
    visited = [False] * len(arrays)

    for i in range(len(arrays)):
        if visited[i]:
            continue
        
        # Start with the current array
        current_merge = set(arrays[i])
        visited[i] = True
        
        # Try to find other arrays to merge with the current one
        for j in range(len(arrays)):
            if i != j and not visited[j] and (current_merge & set(arrays[j])):
                current_merge.update(arrays[j])
                visited[j] = True

        # Add the merged result
        merged.append(list(current_merge))

    return merged

# Collect ucid arrays
arrays = [row['ucid_array'] for row in df_with_array.select("ucid_array").collect()]

# Merge arrays
merged_arrays = merge_arrays(arrays)

# Create final output schema
final_schema = StructType([
    StructField("ucids", ArrayType(StringType()), True),
])

# Create final DataFrame with merged arrays
df_final_output = spark.createDataFrame(data=[(ucids,) for ucids in merged_arrays], schema=final_schema)

# Show size of final merged output
print("Final merged output size:")
df_final_output.select(F.max(F.size(F.col("ucids")))).show()

# Assign a row number to each array
window_spec = Window.orderBy(F.monotonically_increasing_id())
final_with_row_number = df_final_output.withColumn("row_number", F.row_number().over(window_spec))

# Show the result
final_with_row_number.display()




# COMMAND ----------

# DBTITLE 1,phone_nbr_matching_loops
from pyspark.sql import Window
import pyspark.sql.functions as F
from pyspark.sql.types import StructType, StructField, IntegerType, ArrayType, StringType

def merge_arrays_with_common_elements(arrays):
    merged = []  # To hold the merged arrays
    visited = [False] * len(arrays)  # Track which arrays have been merged

    while True:
        current_merge_found = False
        current_merge = []

        for i in range(len(arrays)):
            if visited[i]:
                continue

            temp_merge = set(arrays[i])
            visited[i] = True

            for j in range(i + 1, len(arrays)):
                if not visited[j] and (temp_merge & set(arrays[j])):
                    temp_merge.update(arrays[j])
                    visited[j] = True
                    current_merge_found = True

            current_merge.append(list(temp_merge))

        if not current_merge_found:
            break
        
        arrays = current_merge

    return arrays

def assign_unique_ids(merged_arrays):
    return [(idx, array) for idx, array in enumerate(merged_arrays)]


# Load data with rule 1 applied, this data is matched by ssid
print("loading data with rule 1 applied, this data is matched by ssid")
df0 = spark.sql("SELECT *, NTILE(25) OVER (ORDER BY customerid) AS group_id FROM ce.me_ssid_match where ingestts between '20101008' and '20110201' ")

df0.createOrReplaceTempView("df0")
df0_count = spark.sql("SELECT COUNT(DISTINCT source_system_id) FROM df0")
df0_count.show()

print("adding ssid_ucid column to show previous ucid from rule 1")
df1 = df0.withColumn('ssid_ucid', F.col('customerid'))

print("create window partitioning to group together all rows with matched first_name, last_name, phone_nbr")
window_spec_1 = Window.partitionBy("first_name", "last_name", "phone_nbr")
df2 = df1.withColumn("pn_ucid", F.when(
    (F.col('first_name').isNotNull()) & 
    (F.col('last_name').isNotNull()) & 
    (F.col('phone_nbr').isNotNull()), 
    F.max("customerid").over(window_spec_1)
))

df3 = df2.withColumn("customerid", F.when(
    (F.col('first_name').isNotNull()) & 
    (F.col('last_name').isNotNull()) & 
    (F.col('phone_nbr').isNotNull()), 
    F.col("pn_ucid")
).otherwise(F.col('customerid'))).distinct()

# Initialize final DataFrame
final_df = None

# Loop through each group_id from 1 to 25
for group_id in range(1, 26):
    df_temp = df3.filter(F.col("group_id") == group_id).select("*")
    
    # Create array to hold the list of phone_nbr matches
    df_grouped = df_temp.groupBy('customerid').agg(F.collect_set('source_system_id').alias('ssid')).distinct()
    
    # Prepare arrays for merging
    arrays = [row[0] for row in df_grouped.select("ssid").collect()]
    
    # Call the function to merge arrays
    merged_arrays = merge_arrays_with_common_elements(arrays)
    
    # Assign unique IDs to each merged array
    merged_with_ids = assign_unique_ids(merged_arrays)
    
    # Create DataFrame for this group_id
    schema = StructType([
        StructField("ID", IntegerType(), True),
        StructField("ssids", ArrayType(StringType()), True),
    ])
    
    df_gid = spark.createDataFrame(data=merged_with_ids, schema=schema)
    
    # Union with the final DataFrame
    if final_df is None:
        final_df = df_gid
    else:
        final_df = final_df.union(df_gid)

# Final output DataFrame
print("How many ssids in an array after merging all group_ids?")
final_df.select(F.max(F.size(F.col("ssids")))).show()

# If needed, run the merge function on the final_df ssids
arrays = [row[0] for row in final_df.select("ssids").collect()]
df_final_merged = merge_arrays_with_common_elements(arrays)
merged_with_ids = assign_unique_ids(df_final_merged)

final_schema = StructType([
    StructField("ID", IntegerType(), True),
    StructField("ssids", ArrayType(StringType()), True),
])

df_final_output2 = spark.createDataFrame(data=merged_with_ids, schema=final_schema)

print("Final merged output size:")
df_final_output2.select(F.max(F.size(F.col("ssids")))).show()


# COMMAND ----------

df_final_output2.write.option("overwriteSchema", True).saveAsTable("ce.me_partialphone2", overwrite=True)

# COMMAND ----------

# DBTITLE 1,Phone_nbr matching
#---------------------------- PHONE NBR MATCHING -----------------------------------#

print("loading data with rule 1 applied, this data is matched by ssid")
df0 = spark.sql("select *, NTILE(25) OVER (ORDER BY customerid) AS group_id from ce.me_sfdata_ssid_match") #bring in data already matched by ssid 
#dw0 = spark.read.format("delta").load(self.targetPath2)

df0.createOrReplaceTempView("df0")
df0_count = spark.sql("select count(distinct source_system_id) from df0")
df0_count.show()

print("adding ssid_ucid column to show previous ucid from rule 1")
df1 = df0.withColumn('ssid_ucid', F.col('customerid'))

print("create window partitioning to group together all rows with matched first_name, last_name, phone_nbr")
window_spec_1 = Window.partitionBy("first_name", "last_name", "phone_nbr")
df2 = df1.withColumn("pn_ucid", F.when((F.col('first_name').isNotNull()) & (F.col('last_name').isNotNull()) & (F.col('phone_nbr').isNotNull()), F.max("customerid").over(window_spec_1)))

#-----------do we need a step here to fetch all ssid's which are included in the group, and then assign the ssid to the ucid? Issue is i don't think even at this stage we have consistant ucid accross the group by fetching max() value .... 
#-----------

df3 = df2.withColumn("customerid", F.when((F.col('first_name').isNotNull()) & (F.col('last_name').isNotNull()) & (F.col('phone_nbr').isNotNull()),F.col("pn_ucid")).otherwise(F.col('customerid'))).distinct()
df3.printSchema()
#print("writing table 0")
#df3.write.option("overwriteSchema", "true").saveAsTable("`custanwo`.`ce`.`me_sfdata_phone_match0`",mode="overwrite")
df4 = df3.filter(F.col("group_id") == 1).select("*")
# create array to hold the list of phone_nbr matches 
df5 = df4.groupBy('customerid').agg(F.collect_set('source_system_id').alias('ssid')).distinct()


#df4.printSchema()
#df4.display()

arrays = [row[0] for row in df5.select("ssid").collect()]
id_column = "customerid"

# Call the function to merge arrays
df6 = merge_arrays_with_common_elements(arrays)
    
    # Assign unique IDs to each merged array
merged_with_ids = assign_unique_ids(df6)
schema = StructType([ \
    StructField("ID", IntegerType(), True), \
    StructField("ssids", ArrayType(StringType()), True), \
        ])

df_gid1 = spark.createDataFrame(data=merged_with_ids, schema=schema)

print("how may ssids in an latest array?")
df_gid1.select(F.max(F.size(F.col("ssids")))).show()
    # Print the results

#group_id 2
df7 = df3.filter(F.col("group_id") == 2).select("*")
# create array to hold the list of phone_nbr matches 
df8 = df7.groupBy('customerid').agg(F.collect_set('source_system_id').alias('ssid')).distinct()

arrays = [row[0] for row in df8.select("ssid").collect()]

# Call the function to merge arrays
df8 = merge_arrays_with_common_elements(arrays)
    
    # Assign unique IDs to each merged array
merged_with_ids = assign_unique_ids(df8)
schema = StructType([ \
    StructField("ID", IntegerType(), True), \
    StructField("ssids", ArrayType(StringType()), True), \
        ])

df_gid2 = spark.createDataFrame(data=merged_with_ids, schema=schema)

print("how may ssids in an array?")
df_gid2.select(F.max(F.size(F.col("ssids")))).show()

#merge_1 & 2 
final_df = df_gid1.union(df_gid2)
print("how many ssids in an array after union?")
final_df.select(F.max(F.size(F.col("ssids")))).show()

#run 1&2 union through ssid merge function
arrays = [row[0] for row in final_df.select("ssids").collect()]
id_column = "customerid"
df9 = merge_arrays_with_common_elements(arrays)
    # Assign unique IDs to each merged array
merged_with_ids = assign_unique_ids(df9)
schema = StructType([ \
    StructField("ID", IntegerType(), True), \
    StructField("ssids", ArrayType(StringType()), True), \
        ])

df_gid3 = spark.createDataFrame(data=merged_with_ids, schema=schema)

print("how may ssids in an array?")
df_gid3.select(F.max(F.size(F.col("ssids")))).show()



# COMMAND ----------

print("writing table 4")
df.write.option("overwriteSchema", "true").saveAsTable("`custanwo`.`ce`.`me_sfdata_phone_nbr2`",mode="overwrite")
print("finished....")

# COMMAND ----------

#---------------------------- PHONE NBR MATCHING -----------------------------------#
print("loading data with rule 1 applied, this data is matched by ssid")
df0 = spark.sql("select *from ce.me_ssid_match") #bring in data already matched by ssid 

print("adding ssid_ucid column to show previous ucid from rule 1")
df1 = df0.withColumn('ssid_ucid', F.col('customerid'))

print("create window partitioning to group together all rows with matched first_name, last_name, phone_nbr")
matching_window = Window.partitionBy("first_name", "last_name", "phone_nbr")
ssid_window = Window.partitionBy("ssid_ucid")

df2 = df1.withColumn("pn_ucid", F.when((F.col('first_name').isNotNull()) & (F.col('last_name').isNotNull()) & (F.col('phone_nbr').isNotNull()), F.max("customerid").over(matching_window)))

df3 = (df2.withColumn("new_matched_id", F.min(
                F.min("pn_ucid").over(matching_window)
            ).over(ssid_window)))
df3.display()   

df4 = df3.withColumn("customerid",F.col("new_matched_id")).distinct()

df4.write.option("overwriteSchema", "true").saveAsTable("`custanwo`.`ce`.`me_phone_match`",mode="overwrite")


# COMMAND ----------

# DBTITLE 1,addr matching
print("loading data with rule 1 applied, this data is matched by ssid")
df0 = spark.sql("select * from custanwo.ce.me_phone_match") #bring in data already matched by ssid 

print("adding pn_ucid column to show previous ucid")
df1 = df0.withColumn('pn_ucid', F.col('customerid'))

print("create window partitioning to group together all rows with matched first_name, last_name, billing_address")
matching_window = Window.partitionBy("first_name", "last_name", "billing_address")
ssid_window = Window.partitionBy("pn_ucid")

df2 = df1.withColumn("addr_ucid", F.when((F.col('first_name').isNotNull()) & (F.col('last_name').isNotNull()) & (F.col('billing_address').isNotNull()), F.max("customerid").over(matching_window)))

df3 = df2.withColumn("customerid", F.when((F.col('first_name').isNotNull()) & (F.col('last_name').isNotNull()) & (F.col('billing_address').isNotNull()),F.col("addr_ucid")).otherwise(F.col('customerid'))).distinct()

df4 = (df3.withColumn("new_matched_id", F.when((F.col('first_name').isNotNull()) & (F.col('last_name').isNotNull()) & (F.col('billing_address').isNotNull()), F.min(
                F.min("pn_ucid").over(matching_window)
            ).over(ssid_window))))
df4.display()   

#print("writing table 0")
df4.write.option("overwriteSchema", "true").saveAsTable("`custanwo`.`ce`.`me_addr_match`",mode="overwrite")
'''
# create array to hold the list of addr matches 
df4 = df3.groupBy('customerid').agg(F.collect_set('source_system_id').alias('array_ssid')).distinct()


#df4.display()
df4.createOrReplaceTempView('df4')
#print("writing table 1")
#df4.write.option("overwriteSchema", "true").saveAsTable("`custanwo`.`ce`.`me_sfdata_addr_match1`",mode="overwrite")

##------from df4 can we map this as a dictionary of customerid, ssid array. How to cope with ssid in two arrays? same issue as before?
##------from df4  create a list of cusotmerid and array of ssid's, explode the array? -- doesn't work, still splits ssid accross 1,2,3 ucids

df5 = spark.sql("select customerid, explode(array_ssid) as ssid_explode from df4").distinct()
#print("writing table 2")
#df5.write.option("overwriteSchema", "true").saveAsTable("`custanwo`.`ce`.`me_sfdata_addr_match2`",mode="overwrite")
df5.createOrReplaceTempView('df5')

df6 = spark.sql("select *, max(customerid) over(partition by ssid_explode) as new_ucid from df5")

#df6.write.option("overwriteSchema", "true").saveAsTable("`custanwo`.`ce`.`me_sfdata_phone_match3`",mode="overwrite")

df7 = df3.join(df6, on=[df3.source_system_id == df6.ssid_explode], how='left').drop("ssid_explode", df6.customerid)
#df7.printSchema()
df8 = df7.withColumn('customerid', F.col("new_ucid")).drop("new_ucid").distinct()
print("writing table 4")
df8.write.option("overwriteSchema", "true").saveAsTable("`custanwo`.`ce`.`me_sfdata_addr_match4`",mode="overwrite")
print("finished....")
'''

# COMMAND ----------

# DBTITLE 1,token matching
#-------------------------------------------- TOKEN MATCHING  ------------------------------------------#

print("loading data with rule 0 applied, matched by source_system_id")
df_w4 = spark.read.format("delta").load(self.targetPath1)

print("running token matching stage 1: create table of sf data where token_id is not null (token_id, ucid, ssid)")
df = spark.read.format("delta").load(self.targetPath1)
df_sf_tokens = df.filter((F.col('token_id').isNotNull()) & (F.col('source') == 'sf')).select(F.col('token_id').alias('sf_token_id'),F.col('customerid').alias('ucid'),F.col('source_system_id'), F.col('xref').alias('sf_xref'))

window_spec_4 = Window.partitionBy("sf_token_id")

df_sf_tokens = df_sf_tokens.withColumn('ucid', F.max("ucid").over(window_spec_4))


print("running token matching stage 2: join store data columns ucid and token_id on token_id using left outer join to show any store data records where no token match exists ")

df_store_tokens = df.filter((F.col('source') == 'store')).select(F.col('token_id').alias('store_token_id'),F.col('xref').alias('store_xref'), F.col('customerid').alias('ucid_prev'))

print("running token matching stage 3: join together sf and store tokens and write out to file for checking")
df_tokens = df_sf_tokens.join(df_store_tokens, df_sf_tokens.sf_token_id == df_store_tokens.store_token_id, how='fullouter')
df_tokens = df_tokens.withColumn('ucid', F.when(F.col('ucid').isNull(), F.col('ucid_prev')).otherwise(F.col('ucid')))

df_tokens.createOrReplaceTempView('tokens')
df_tokens_final = spark.sql("""select distinct ucid, coalesce(sf_token_id, store_token_id) final_token_id, coalesce(source_system_id, store_token_id,store_xref) source_system_id from tokens""") 
#we now have a list of token_ids and their unique ucids

##steps here to join df back on itself where spid = spid but customer_id != customerid 
df1 = df_tokens_final.select ('ucid','final_token_id','source_system_id')
df2 = df_tokens_final.select ('ucid','final_token_id','source_system_id').withColumnsRenamed({'ucid':'ucid_2','final_token_id':'final_token_id_2','source_system_id':'source_system_id_2'})

df3 = df1.join(df2, (df1.source_system_id == df2.source_system_id_2) & ~(df1.ucid == df2.ucid_2), how='left').distinct()

df4 = df3.filter(~(F.col('ucid_2') == F.col('ucid'))).select(F.col('ucid'), F.col('final_token_id_2'), F.col('source_system_id'))
df5 = df3.select(F.col('ucid'), F.col('final_token_id'), F.col('source_system_id')).distinct()

df6 = df5.union(df4).distinct()
df6 = df6.groupBy(F.col('source_system_id').alias('source_system_id'), 
            F.col('final_token_id').alias('final_token_id')) \
    .agg(F.max(F.col('ucid')).cast(DecimalType(20, 0)).alias('ucid'))

window_spec_5 = Window.partitionBy("final_token_id")
df7 = df6.withColumn('ucid', F.max("ucid").over(window_spec_5)).distinct()
df7.display()
#df6.write.mode("overwrite").option("overwriteSchema", "true").format("delta").save(self.token_match) #Rule 4 table 
df7.write.option("overwriteSchema", "true").saveAsTable("`custanwo`.`ce`.`me_token_match`",mode="overwrite")


# COMMAND ----------

# DBTITLE 1,final transformations and select
     
# full validation should be done up to here, when full validation is complete then above write statement can be removed 
##stop code here ## only carry on when ready to write the full table
'''
df_w6 = spark.read.format("delta").load(self.targetPath5) 
final_df = df_w6.withColumn("customerid", F.concat(F.lit('U-'),F.col("customerid").cast("string"))).withColumn("cbb_seen",F.date_format(F.current_timestamp(),"yyyy-MM-dd HH:mm:ss")).withColumn("version",F.date_format(F.current_timestamp(),"yyyyMMddHHmm"))

# write final df to cdd_raw_unified_customer_table

write_df = (final_df
                .select(F.col("customerid")
                ,F.col("crm_customer_id")
                ,F.col('source_system_id')
                ,F.col("title")
                ,F.col("first_name")
                ,F.col("middle_name")
                ,F.col("last_name")
                ,F.col("email_id")
                ,F.col("phone_nbr")
                ,F.col("pihash")
                ,F.col("xref")
                ,F.col("token_id")
                ,F.col("guest_order_ind")
                ,F.col("billing_first_name")
                ,F.col("billing_last_name")
                ,F.col("billing_address1")
                ,F.col("billing_address2")
                ,F.col("billing_address3")
                ,F.col("billing_address4")
                ,F.col("billing_address5")
                ,F.col("billing_address6")
                ,F.col("billing_city")
                ,F.col("billing_county")
                ,F.col("billing_zip_Cd")
                ,F.col("billing_state")
                ,F.col("billing_country")
                ,F.col("billing_address")
                ,F.col("latitude")
                ,F.col("longitude")
                ,F.col("blacklist")
                ,F.col("cbb_seen")
                ,F.col("version")
                ,F.col("source")
                ,F.col("ingestts")                       
                    ))             

write_df = write_df.withColumn("version_date", F.substring(write_df.version, 1,8))

#write out to storage account, remove any duplication and repartition by version_date
write_df = write_df.distinct().repartition('version_date')

#encrypt cc details 
encryptionKey = dbutils.preview.secret.get(scope = self.dbScope, key = "{}".format('customer-secret'))
encrypt = udf(encrypt_values, StringType())
for column in self.encrypt_columns:
    write_df = write_df.withColumn(column,encrypt(str(column), F.lit(encryptionKey))) 

#write_df.write.mode("overwrite").option("overwriteSchema", "true").format("delta").save(self.targetPath)
'''

# COMMAND ----------

# DBTITLE 1,CHECKING / VALIDATION / ANALYSIS
duc = spark.read.format("delta").load("/mnt/eim/business/internal/ce/raw/cdd_raw_unified_customer")
duc.createOrReplaceTempView("duc")

tids = spark.read.format("delta").load("/mnt/stg/business/internal/iddi/rdl/gb_customer_data_domain_odl/cdd_odl_transaction_ids")
tids.createOrReplaceTempView("tids")

dcust = spark.read.format("delta").load("/mnt/eim/business/internal/infoMart/dimensions/dim_customer/")
dcust.createOrReplaceTempView("dcust")

##cust_Addr =  spark.read.format("delta").load("/mnt/stg/business/confidential/iddi/rdl/gb_customer_secured_dl_tables/cust_addr")
#cust_Addr.createOrReplaceTempView("addr")

custCard = spark.read.format("delta").load("/mnt/stg/business/confidential/iddi/rdl/gb_customer_secured_dl_tables/cust_card/")
custCard.createOrReplaceTempView("custcard")

svt = spark.read.format("delta").load("/mnt/stg/business/confidential/iddi/rdl/gb_mb_store_secured_dl_tables/store_visit_tender/")
#df_write_txt = svt.select("acct_nbr")
#df_write_txt.write.mode("overwrite").format("text").save("/mnt/enh/business/confidential/iddi/rdl/gb_mb_store_secured_dl_tables/store_visit_tender.txt")
svt.createOrReplaceTempView("svt")

cust = spark.read.format("delta").load("/mnt/stg/business/confidential/iddi/rdl/gb_customer_secured_dl_tables/cust") 
cust.createOrReplaceTempView("cust")

stg1 = spark.read.format("delta").load("/mnt/eim/business/internal/ce/raw/stg1_uc")
stg1.createOrReplaceTempView("stg1")

xref_mapping = spark.read.format("delta").load("/mnt/stg/business/internal/iddi/rdl/gb_mb_store_secured_dl_tables/xref_surrogate_token")
xref_mapping.createOrReplaceTempView("xref_mapping")

stg2 = spark.read.format("delta").load("/mnt/eim/business/internal/ce/raw/stg2_uc")
stg2.createOrReplaceTempView("stg2")

stg3 = spark.read.format("delta").load("/mnt/eim/business/internal/ce/raw/stg3_uc")
stg3.createOrReplaceTempView("stg3")

stg4 = spark.read.format("delta").load("/mnt/eim/business/internal/ce/raw/stg4_uc")
stg4.createOrReplaceTempView("stg4")

stg5 = spark.read.format("delta").load("/mnt/eim/business/internal/ce/raw/stg5_uc")
stg5.createOrReplaceTempView("stg5")

#stg6 = spark.read.format("delta").load("/mnt/eim/business/internal/ce/raw/stg6_uc")
#stg6.createOrReplaceTempView("stg6")

lookup = spark.read.format("delta").load("/mnt/eim/business/internal/ce/raw/lookup_table")
lookup.createOrReplaceTempView("lookup")



# COMMAND ----------

# MAGIC %sql
# MAGIC --select * from xref_mapping xm inner join (select xref from stg1 where source = 'store' and token_id is null ) a on a.xref = xm.xref_token_id 
# MAGIC
# MAGIC select distinct * from (select distinct xref from stg1 where source = 'store' and token_id is null) a left join (select xref, token_id, source_system_id from stg1 where source = 'sf' and token_id is null) b on a.xref = b.xref

# COMMAND ----------

# MAGIC %sql
# MAGIC select source_system_id, count(distinct customerid), count(distinct token_id) from lookup group by source_system_id having count(distinct token_id) > 1

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from lookup where source_system_id in ('5f35d283-7c88-4f6a-924d-ebb37d69fd23') 

# COMMAND ----------

# MAGIC %sql
# MAGIC with a as (
# MAGIC  select distinct lookup.customerid, stg4.source_system_id, stg4.token_id 
# MAGIC , case when stg4.token_id is not null then max(lookup.customerid) over(partition by stg4.token_id) end as new_customerid_token
# MAGIC from stg4 left join lookup on stg4.token_id = lookup.token_id where lookup.customerid is not null and source = 'sf'
# MAGIC )
# MAGIC --select source_system_id, count(distinct new_customerid) from a where token_id is not null group by source_system_id having count(distinct new_customerid) > 1 
# MAGIC select customerid, source_system_id, token_id, new_customerid_token, max(new_customerid_ssid) over(partition by token_id) new_customerid_token2 from 
# MAGIC (SELECT customerid, source_system_id, token_id, new_customerid_token, max(new_customerid_token) over(partition by source_system_id) new_customerid_ssid from a ) b
# MAGIC
# MAGIC --where source_system_id = 'cb41fea05d754c4a997cd78d5b111984'
# MAGIC
# MAGIC where token_id in ('475117b69678e5b4914',
# MAGIC '465865c03d828642027',
# MAGIC '465865cce3c87409013',
# MAGIC '46586568c8b0fe52035',
# MAGIC '465859651f4893b7030') --expecting all ucids to be 9999999999914322937
# MAGIC
# MAGIC --where lookup.customerid in ('9999999999871510296', '9999999999959620322')
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from custCard 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from stg4 where source_system_id in ('5f35d283-7c88-4f6a-924d-ebb37d69fd23') 
# MAGIC --select * from stg4 where customerid = '9999999999871510296'
# MAGIC --select * from stg4 where token_id = '341263a4d5d8b571009'

# COMMAND ----------

# MAGIC %sql
# MAGIC with a as (select source_system_id, max(max_version) as max_version from lookup group by source_system_id) 
# MAGIC
# MAGIC select count(distinct lookup.source_system_id)
# MAGIC --select lookup.* 
# MAGIC from lookup inner join a on lookup.source_system_id = a.source_system_id and lookup.max_version = a.max_version
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from lookup where source_system_id in ('33b5d457616c4901bc9fdb5e44106faf',
# MAGIC '585d10c8-f30d-4ac8-a142-8edd4b1f5a27',
# MAGIC '6fbf090b4db8414eb71bb55ac8bf3877')

# COMMAND ----------

# MAGIC %sql
# MAGIC select acct_nbr, xref_token_id, count(distinct token_id) from svt left join xref_mapping x on trim(svt.acct_nbr) = x.xref_token_id group by acct_nbr, xref_token_id order by count(token_id) desc

# COMMAND ----------

# DBTITLE 1,checking stages of matching
# MAGIC %sql
# MAGIC select count(*), count(distinct customerid), count(distinct source_system_id), count(distinct xref) from stg1 where source = 'sp'--checking each row has been assigned a unique ucid regardless of ssid or xref 
# MAGIC -- in the next pass we expect that the count of ucids will have dropped to match the number of distinct ssids.

# COMMAND ----------

# MAGIC %sql
# MAGIC select source, count(source_system_id), count(distinct source_system_id) from stg1 group by source

# COMMAND ----------

# MAGIC %sql
# MAGIC select source_system_id, count(source_system_id) from stg1 where source = 'store' group by source_system_id having count(source_system_id) > 1

# COMMAND ----------

# MAGIC %sql
# MAGIC select source_system_id, token_id, xref, ingestts from stg1 where source_system_id in ('492181781bb5ac25248',
# MAGIC '4751298806e6fa99002',
# MAGIC '446272383fd84507580',
# MAGIC '4751179c51d0c029490')

# COMMAND ----------

# MAGIC %sql
# MAGIC select source, count(customerid), count(distinct customerid), count(source_system_id), count(distinct source_system_id) from stg5 group by source

# COMMAND ----------

# MAGIC %sql
# MAGIC select  count(customerid), count(distinct customerid), count(source_system_id), count(distinct source_system_id), count(token_id), count(distinct token_id) from stg5 

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select count(distinct first_name)
# MAGIC --first_name, last_name, phone_nbr, count(distinct customerid) 
# MAGIC from stg5 
# MAGIC group by first_name, last_name, phone_nbr 
# MAGIC having count(distinct customerid) > 1

# COMMAND ----------

# MAGIC %sql
# MAGIC select token_id, count(distinct customerid), count(distinct source_system_id) from stg3 group by token_id having count(distinct customerid) > 1

# COMMAND ----------

# MAGIC %sql
# MAGIC select source_system_id, count(distinct customerid) 
# MAGIC from stg3
# MAGIC group by source_system_id
# MAGIC having count(distinct customerid) > 1 -- should be no results 

# COMMAND ----------

select * from stg3 where source_system_id in ('281cbd41-8110-4cad-a2bc-b29d7937b6d0',
'ae09c186-a951-427e-997f-489f4823df9c',
'f5afa492-b798-4ffc-a117-ed7271fbf14a',
'fd364570-7cad-43c1-835e-ca1249f6532a',
'96adb089-48e9-499e-9611-1169d9481021')

# COMMAND ----------

# MAGIC %sql
# MAGIC select first_name, last_name, billing_address1, count(distinct customerid), count(distinct source_system_id) 
# MAGIC from duc
# MAGIC group by first_name, last_name, billing_address1
# MAGIC having count(distinct customerid) > 1

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC SELECT a.customerid, b.token_count, c.spid_count FROM (
# MAGIC SELECT DISTINCT(customerid) FROM duc WHERE version_date = '20240912') a
# MAGIC LEFT JOIN
# MAGIC (SELECT customerid, COUNT(DISTINCT source_system_id) AS token_count FROM duc
# MAGIC WHERE version_date = '20240912' AND source = 'store'
# MAGIC GROUP BY customerid) b
# MAGIC ON a.customerid = b.customerid
# MAGIC LEFT JOIN (SELECT customerid, COUNT(DISTINCT source_system_id) AS spid_count FROM duc
# MAGIC WHERE version_date = '20240912' AND source = 'sp'
# MAGIC GROUP BY customerid) c
# MAGIC ON a.customerid = c.customerid
# MAGIC  
# MAGIC  
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select acct_nbr, count(distinct token_id)
# MAGIC from svt
# MAGIC group by acct_nbr 
# MAGIC having count(distinct token_id) >1

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from tids where lead_token_id in ('46586573b0c129d9031','434612274d85f751519')

# COMMAND ----------

# MAGIC %sql
# MAGIC select customerid, count(distinct source_system_id)
# MAGIC from duc
# MAGIC group by customerid
# MAGIC having count(distinct source_system_id) > 21

# COMMAND ----------

# MAGIC %sql
# MAGIC --select count(distinct customerid), count(distinct source_system_id), count(distinct xref) 
# MAGIC
# MAGIC select * from duc where customerid in ('U-9999999999999970963')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from duc where xref in ('121024724894',
# MAGIC '123397096306',
# MAGIC '118928785112',
# MAGIC '124745931541',
# MAGIC '119764968291',
# MAGIC '125267598675',
# MAGIC '116378176667')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from svt where acct_nbr in ('121024724894',
# MAGIC '123397096306',
# MAGIC '118928785112',
# MAGIC '124745931541',
# MAGIC '119764968291',
# MAGIC '125267598675',
# MAGIC '116378176667')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from duc where token_id in ('44629161bb651709933', '45431315b9715979529', '45431325ebae4f04224', '46586504e860ce84018',
# MAGIC '465902298b456960039', '492181020b27c466284', '492182772d6e74d5233', '525303813bbe0cf2115')

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql import functions as F
from pyspark.sql.types import DecimalType

window_spec_ordering = Window.orderBy("data_src_cd")

df = cust.withColumn("row_number",F.row_number().over(window_spec_ordering))
max_id = "10000000000000000000"
max_id = (F.lit(max_id)).cast(DecimalType(20, 0))
#df = df.filter('last_nm is not null and last_nm != "" and first_nm is not null and first_nm != "" and email_id is not null and email_id != "" ')
df = df.withColumn("customerid",max_id-F.col("row_number").cast(DecimalType(20, 0)))
#df = df.drop("row_number")
display(df)

window_spec_0 = Window.partitionBy(df.data_src_cd)

df_w1 = df.withColumn("max_customerid",F.max("customerid").over(window_spec_0))
df_w1 = df_w1.withColumn('customerid', F.when(F.col('last_nm').isNotNull() & F.col('first_nm').isNotNull() & F.col('email_id').isNotNull(),F.col("max_customerid")).otherwise(F.col('customerid')))

df_w1.createOrReplaceTempView("df_w1")

display(df_w1)


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from df_w1 where email_id = 'dianealton@chas.org.uk' 

# COMMAND ----------

# MAGIC %sql
# MAGIC select email_id, count(email_id) 
# MAGIC from df_w1 
# MAGIC group by email_id 
# MAGIC having count(email_id) > 1 
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select visit_dt, count(*) from svt
# MAGIC where visit_dt between '2024-08-14' and '2024-08-16'
# MAGIC group by visit_dt
# MAGIC
# MAGIC --2024-08-14	2460726
# MAGIC --2024-08-15	2543300
# MAGIC --2024-08-16	2807110
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from custCard where singl_profl_id is null and pymt_token_txt is not null 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from duc 
# MAGIC where email_id in ('test1aa1asasa1011aaaaaaa3aaa11@gmail.com')

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from duc where source_system_id is null and first_name is null and last_name is null and email_id is null and phone_nbr is null 

# COMMAND ----------

# MAGIC %sql
# MAGIC select ingestts from duc group by ingestts order by ingestts desc
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select first_name, last_name, email_id, count(distinct customerid) 
# MAGIC from duc 
# MAGIC group by first_name, last_name, email_id 
# MAGIC having count(distinct customerid) >1

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from tids where lead_xref = '62286437801'

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*),count(distinct customerid), count(distinct customerid), count(distinct source_system_id) from duc

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from addr where gdpr_del_ind = 0 and cust_del_ind = 0 and addr_usag_type_nm = 'shipTo' and addr_line_1_txt not like '%DUMMY%'
# MAGIC order by singl_profl_id, ver_nbr 
# MAGIC --where singl_profl_id = 'a709cb99-5c05-4940-872a-b044dbfc7236'

# COMMAND ----------

# MAGIC %sql
# MAGIC select bk_crm_customer_id, count(*) from dcust group by bk_crm_customer_id order by bk_crm_customer_id asc

# COMMAND ----------

# MAGIC %sql
# MAGIC select prefix,first_name,last_name,middle_name,email,registration_date,date_of_birth
# MAGIC from dcust
# MAGIC group by prefix,first_name,last_name,middle_name,email,registration_date,date_of_birth
# MAGIC having count(bk_singl_profl_id) >1
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from duc where xref in (
# MAGIC '115735811198'
# MAGIC
# MAGIC )
# MAGIC '101490034390',
# MAGIC '120532880024',
# MAGIC '116421441449',
# MAGIC '117177140607',
# MAGIC '120270608843',
# MAGIC '115800535763',
# MAGIC '118465248862',
# MAGIC '120979379860',
# MAGIC '120152479719',
# MAGIC '121380502587',
# MAGIC '121947786723'
# MAGIC ) 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from cust where upper(channel_id) in ('GROCERY')

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(basket_id), count(singl_profl_id)
# MAGIC from tids 
# MAGIC where channel_id = 2 
# MAGIC and visit_dt >='2021-7-30' and visit_dt <='2024-07-28' 
# MAGIC and non_scan_visit_ind = 0 
# MAGIC --and singl_profl_id is not null 

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(basket_id) from tids where non_scan_visit_ind = 0 and visit_dt >='2021-08-01' and visit_dt <= '2024-08-01'

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*), count(distinct xref),  count(distinct crm_id), count(distinct source_system_id) from duc
# MAGIC
# MAGIC where xref is not null 

# COMMAND ----------

# MAGIC %sql 
# MAGIC select source_system_id from duc where xref is null and source_system_id is not null

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*), count(lead_xref), count(lead_token_id), count(distinct singl_profl_id) from tids

# COMMAND ----------

# MAGIC %md
# MAGIC This query highlights where xrefs are in transaction_ids table but not in dim_unified_customer, this also effects number of singl_profl_id matches to dim_customer_v2
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC --select singl_profl_id, count(lead_xref) from tids group by singl_profl_id
# MAGIC select lead_xref, count(distinct singl_profl_id) from tids group by lead_xref having count(singl_profl_id) > 1 
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from tids where lead_xref = '142017305285'

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from ((
# MAGIC select distinct lead_xref from tids) og left join (
# MAGIC select distinct xref from duc ) jn on og.lead_xref = jn.xref ) a
# MAGIC where a.xref is null 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from tids where lead_xref in ('100728581792',
# MAGIC '103466098508',
# MAGIC '104653625616',
# MAGIC '105598981386',
# MAGIC '106650675619',
# MAGIC '10665509161',
# MAGIC '109408640083',
# MAGIC '110536590901',
# MAGIC '110571930178',
# MAGIC '110898776049',
# MAGIC '111068266050',
# MAGIC '111177230930',
# MAGIC '111423690093',
# MAGIC '111550439389',
# MAGIC '111585049518')

# COMMAND ----------

# MAGIC %sql
# MAGIC select basket_id, count(singl_profl_id) from tids group by basket_id having count(singl_profl_id) > 1

# COMMAND ----------

# MAGIC %md
# MAGIC this is to analyse data from store_visit_tender, when compared with the same query run in old world dremio there are big gaps so have passed to Rama to rectify 

# COMMAND ----------

# MAGIC %sql
# MAGIC select visit_dt, count(distinct acct_nbr) 
# MAGIC from svt 
# MAGIC where tndr_type_cd = 8 and visit_dt > date_sub(current_date(), 1096)
# MAGIC group by visit_dt order by visit_dt asc
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC This query highlights any spids that exist in dim_customer_v2 but not in dim_unified_customer

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(bk_singl_profl_id), count(distinct bk_singl_profl_id)
# MAGIC from dcust

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(distinct bk_singl_profl_id)
# MAGIC , count(distinct bk_crm_customer_id)
# MAGIC , count(distinct singl_profl_id)
# MAGIC from dcust 
# MAGIC left join tids 
# MAGIC on tids.singl_profl_id = dcust.bk_singl_profl_id 
# MAGIC --and tids.lead_xref is not null
# MAGIC  

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct source_system_id from duc where length(source_system_id) > 35 limit 50 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from duc where source_system_id = xref 