# Databricks notebook source
import functools
import operator

import pyspark.sql.functions as F
from pyspark.sql import DataFrame
from pyspark.sql.window import Window


def get_filtered_input(
    input_sdf: DataFrame, cols_to_match: list
) -> tuple[DataFrame, DataFrame]:
    """
    Filter the input DataFrame based on the columns to match.

    Args:
        input_sdf (DataFrame): The input DataFrame.
        cols_to_match (list): The list of column names to match.

    Returns:
        DataFrame: The filtered DataFrame.
        DataFrame: The quarantined DataFrame.
    """
    MATCHING_CONDITION = functools.reduce(
        operator.and_, [F.col(col_name).isNotNull() for col_name in cols_to_match]
    )  # make sure cols to match are all not null
    filtered_sdf = input_sdf.where(MATCHING_CONDITION).withColumnRenamed(
        "matching_id", "old_matching_id"
    )
    quarantined_sdf = input_sdf.where(~MATCHING_CONDITION)

    return filtered_sdf, quarantined_sdf


def get_new_matching_ids(filtered_sdf: DataFrame, cols_to_match: list) -> DataFrame:
    """
    Get the new matching IDs based on the filtered DataFrame and columns to match.

    Args:
        filtered_sdf (DataFrame): The filtered DataFrame.
        cols_to_match (list): The list of column names to match.

    Returns:
        DataFrame: The DataFrame with new matching IDs.
    """
    matching_window = Window.partitionBy(*cols_to_match)
    ssid_window = Window.partitionBy("source_system_id")

    output_sdf = filtered_sdf.withColumns(
        {
            # Count of unique source system IDs within the matching window
            "ssid_group_count": F.size(
                F.collect_set("source_system_id").over(matching_window)
            ),
            # Minimum old matching ID within the source system ID window
            "new_matching_id": F.min(
                F.min("old_matching_id").over(matching_window)
            ).over(ssid_window),
        }
    )
    return output_sdf


def get_changed_matching_id_mapping(
    new_matching_ids_sdf: DataFrame,
) -> DataFrame:
    """
    Get the mapping of changed matching IDs based on the new matching IDs DataFrame.

    Args:
        new_matching_ids_sdf (DataFrame): The DataFrame with new matching IDs.

    Returns:
        DataFrame: The DataFrame with changed matching ID mapping.
    """  # noqa: E501
    old_matching_id_window = Window.partitionBy("old_matching_id")

    changed_matching_id_map_sdf = (
        new_matching_ids_sdf.select(
            "old_matching_id",
            F.min("new_matching_id")
            .over(old_matching_id_window)
            .alias("new_matching_id"),
        )
        .where(F.col("old_matching_id") != F.col("new_matching_id"))
        .distinct()
    )  # multiple records for a single ssid due to multiple xrefs/addresses
    return changed_matching_id_map_sdf


def get_ssid_rule_number_mapping(
    new_matching_ids_sdf: DataFrame, rule_number: int
) -> DataFrame:
    """
    Get the mapping of SSID to rule number based on the new matching IDs DataFrame
    and rule number.

    Args:
        new_matching_ids_sdf (DataFrame): The DataFrame with new matching
        IDs.
        rule_number (int): The rule number.

    Returns:
        DataFrame: The DataFrame with SSID to rule number mapping.
    """  # noqa: E501
    rule_number_sdf = (
        new_matching_ids_sdf.where(F.col("ssid_group_count") > 1)
        .select("source_system_id", F.lit(str(rule_number)).alias("tmp_rules"))
        .distinct()
    )  # multiple records for a single ssid due to multiple xrefs/addresses
    return rule_number_sdf


def apply_maps(
    filtered_input_w_new_matching_ids_sdf: DataFrame,
    changed_matching_id_map_sdf: DataFrame,
    ssid_rule_number_map_sdf: DataFrame,
) -> DataFrame:
    """
    Apply the mapping to the filtered input DataFrame based on the changed matching ID
    map and SSID to rule number map.

    Args:
        filtered_input_w_new_matching_ids_sdf (DataFrame): The DataFrame
        with filtered input and new matching IDs.
        changed_matching_id_map_sdf (DataFrame): The DataFrame with changed
        matching ID mapping.
        ssid_rule_number_map_sdf (DataFrame): The DataFrame with SSID to
        rule number mapping.

    Returns:
        DataFrame: The DataFrame with applied maps.
    """
    filtered_input_w_new_matching_ids_sdf = filtered_input_w_new_matching_ids_sdf.alias(
        "filtered_input_w_new_matching_ids_sdf"
    )
    changed_matching_id_map_sdf = changed_matching_id_map_sdf.alias(
        "changed_matching_id_map_sdf"
    )

    output_sdf = (
        filtered_input_w_new_matching_ids_sdf.join(
            changed_matching_id_map_sdf,
            on=F.col("filtered_input_w_new_matching_ids_sdf.new_matching_id")
            == F.col("changed_matching_id_map_sdf.old_matching_id"),
            how="left",
        )
        .join(ssid_rule_number_map_sdf, on="source_system_id", how="left")
        .withColumn(
            "rules",
            F.when(F.col("tmp_rules").isNull(), F.col("rules")).otherwise(
                F.concat_ws(",", "rules", "tmp_rules")
            ),  # overwrite existing rules column
        )
        .select(
            *[
                col
                for col in filtered_input_w_new_matching_ids_sdf.columns
                if col not in {"old_matching_id", "new_matching_id"}
            ],
            F.coalesce(
                F.col("changed_matching_id_map_sdf.new_matching_id"),
                F.col("filtered_input_w_new_matching_ids_sdf.new_matching_id"),
                F.col("filtered_input_w_new_matching_ids_sdf.old_matching_id"),
            ).alias("matching_id")
        )
        .drop("tmp_rules", "ssid_group_count")
    )
    return output_sdf


def match_records(
    input_sdf: DataFrame, cols_to_match: list, rule_number: int
) -> DataFrame:
    """
    Match records on the specified column names.
    Records that are matched together will have the same `matching_id`.

    Args:
        input_sdf (DataFrame): The input DataFrame.
        cols_to_match (list): The list of column names to match.
        rule_number (int): The rule number.

    Returns:
        DataFrame: The output DataFrame, containing a new column `matching_id`
        that indicates which records have been matched together.
    """
    filtered_sdf, quarantined_sdf = get_filtered_input(
        input_sdf=input_sdf, cols_to_match=cols_to_match
    )

    filtered_input_w_new_matching_ids_sdf = get_new_matching_ids(
        filtered_sdf=filtered_sdf, cols_to_match=cols_to_match
    )
    changed_matching_id_map_sdf = get_changed_matching_id_mapping(
        new_matching_ids_sdf=filtered_input_w_new_matching_ids_sdf
    )
    ssid_rule_number_map_sdf = get_ssid_rule_number_mapping(
        new_matching_ids_sdf=filtered_input_w_new_matching_ids_sdf,
        rule_number=rule_number,
    )

    new_matched_sdf = apply_maps(
        filtered_input_w_new_matching_ids_sdf=filtered_input_w_new_matching_ids_sdf,
        changed_matching_id_map_sdf=changed_matching_id_map_sdf,
        ssid_rule_number_map_sdf=ssid_rule_number_map_sdf,
    )

    output_sdf = new_matched_sdf.unionByName(quarantined_sdf)
    return output_sdf