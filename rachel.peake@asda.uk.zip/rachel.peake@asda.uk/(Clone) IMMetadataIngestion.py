# Databricks notebook source
# MAGIC %run /scripts/genericIngestion/genericIngestionModules/genericModules

# COMMAND ----------

import pyspark.sql.functions as F
from datetime import datetime as dt
from pyspark.sql.types import StructType, StructField, LongType, StringType, DateType, IntegerType

# COMMAND ----------

class dataQuality:

    def notNull(df,columnList):
        failedNullColumns = []
        dqStatus = 'success'
        for column in columnList:
            nullCount = df.where(df[f'{column}'].isNull()).count()
            if nullCount > 0:
                failedNullColumns.append(column)
        
        if len(failedNullColumns) > 0:
            dqStatus = 'failed'
        return dqStatus , failedNullColumns
    
    def columnValueCheck(df, columnName, acceptedList):
        dqStatus = 'success'
        invalidValues = []

        givenValues = df.select(F.lower(F.col(columnName)).alias('columnName')).distinct().rdd.map(lambda x:x.columnName).collect()
        for value in givenValues:
            if value not in set(acceptedList):
                invalidValues.append(value)

        if len(invalidValues) > 0:
            dqStatus = 'failed'

        return dqStatus, invalidValues
    


# COMMAND ----------

class imMetadataIngestion:

    def __init__(self):
        self.env = ''
        self.instance = ''
        genericModules.utils.getEnvVariable(self)
        self.loc = 'uks'

        # Storage Account Variable
        self.landingStorageAccount = 'saasllnddtadm{}{}01'.format(self.env,self.loc)
        self.metadatamount = '/mnt/metadata/'
        self.metadataContainer = 'metadata'
        self.rawContainer = 'sensitive'
        self.dbScope = 'kv-sa-lnd-{}-{}-01'.format(self.env,self.loc)
        self.landindSaKey = 'sas-token-lnd-{}-{}-01'.format(self.env,self.loc)
        self.tempDir = "abfss://{}@{}.dfs.core.windows.net/synapseProcessing".format(self.rawContainer,self.landingStorageAccount)

        # Syanpse Variable
        self.synUser = 'sqladminuser'
        self.synKeyID = 'ukssynPassword'
        self.synServer = 'syn-eimprc-{}-{}-01'.format(self.env,self.loc)
        self.ceAdminDB = 'syn_sql_ceadmin_{}_{}_01'.format(self.env,self.loc)
        self.metadataTableName = 'admin.eimIMMetadata'
        self.jdbcPassword = dbutils.secrets.get(scope = self.dbScope, key = self.synKeyID)
        self.connectionProperties = {
            "password":self.jdbcPassword,
            "driver" : "com.microsoft.sqlserver.jdbc.SQLServerDriver"
            }
        #runTime Variables
        self.checkDate = dt.now().strftime("%Y-%m-%d %H:%M:%S")

        
        # metadata quality check values

        self.nonNullColumns = ['sNo','schemaName','tableName','tableType','columnOrder','columnName','columnDataType','dataDomain','securityClassification']
        self.schemaName = ['info_mart','businessVault']
        self.tableType = ['dimension','fact','bv']
        self.columnDataType = ['varchar','nvarchar','decimal','int','integer','smallint','bigint','date','datetime2']
        self.pk = self.fk = self.partitionKey = ['y',None]
        self.nullable = ['y','n']
        self.dataDomain = ['business','colleague']
        self.securityClassification = ['internal','confidential','secret']
        self.piiCategory = ['colleague-confidential','colleague-secret','supplier-confidential','supplier-secret','customer-confidential','customer-secret',None]


    def getURL(self,server,database,user):
        jdbcURL = "jdbc:sqlserver://{}.sql.azuresynapse.net:1433;database={};user={};".format(server,database,user)
        return jdbcURL

    def readDelimitedFile(self, filePath,SchemaStatus,headerStatus,delimiter,schema=None):
        if not schema:
            df = spark.read.format("csv").option("inferSchema",SchemaStatus).option("header",headerStatus).option("sep",delimiter).load("{}".format(filePath))
        else:
            df = spark.read.format("csv").schema(schema).option("inferSchema",SchemaStatus).option("header",headerStatus).option("sep",delimiter).load("{}".format(filePath))
        return df

    def getSynTable(self, connectionUrl, tableName):
        df = spark.read.jdbc(url=connectionUrl, table=tableName,properties = self.connectionProperties)
        return df
    
    def loadSynTable(self, df,tableName):
        df.write.format("com.databricks.spark.sqldw").mode('append') \
            .option("url","jdbc:sqlserver://{}.sql.azuresynapse.net:1433;database={};user={};password={}".format(self.synServer,self.ceAdminDB,self.synUser, self.jdbcPassword)) \
            .option("useAzureMSI", "true") \
            .option("dbtable",tableName) \
            .option("tempDir", self.tempDir).save()

    def metadataSchema(self):
        metadata_schema = StructType([
            StructField("sNo",IntegerType(), True),
            StructField("schemaName",StringType(), True),
            StructField("tableName",StringType(), True),
            StructField("tableType",StringType(), True),
            StructField("columnType",StringType(), True),
            StructField("columnOrder",IntegerType(), True),
            StructField("columnName",StringType(), True),
            StructField("columnDataType",StringType(), True),
            StructField("columnPrecision",IntegerType(), True),
            StructField("columnScale",IntegerType(), True),
            StructField("nullable",StringType(), True),
            StructField("pk",StringType(), True),
            StructField("fk",StringType(), True),
            StructField("partitionKey",StringType(), True),
            StructField("columnIndex",StringType(), True),
            StructField("dataDomain",StringType(), True),
            StructField("securityClassification",StringType(), True),
            StructField("piiCategory",StringType(), True),
            StructField("tableDescription",StringType(), True),
            StructField("columnDescription",StringType(), True),
            StructField("transformationDescription",StringType(), True),
            StructField("dataModelDomainL1",StringType(), True),
            StructField("dataModelDomainL2",StringType(), True),
            StructField("dataModelDomainL3",StringType(), True),
        ])
        return metadata_schema
    


    def run(self,metadataFileName):
        print("***************Loadin RV Metadata to SQL Program Started*************************")

        spark.conf.set("fs.azure.account.key.saasllnddtadm{}{}01.dfs.core.windows.net".format(self.env,self.loc),dbutils.secrets.get(scope = self.dbScope, key = "saas-ak-lnd-{}-{}-01".format(self.env,self.loc)))

        # Get the metadata file
        metadataFilePath = self.metadatamount + 'eim/metadata/info_mart/'
        metadataFilePath = metadataFilePath + metadataFileName
        print("file {} processing".format(metadataFilePath))
        schema = self.metadataSchema()
        metadataDF = self.readDelimitedFile(metadataFilePath,True,True,',',schema)
        
        # Add metadata columns
        metadataDF = metadataDF.withColumn('md_FileName',F.lit(metadataFileName)).withColumn('md_loadDate',F.lit(self.checkDate))
        #display(metadataDF.where(metadataDF['dvSchema'].isNull()))
        display(metadataDF)

        # perform qualityChecks on metadata sheet.
        dqResult = []

        # check for nulls in mandatory columns

        nonNullCheckResult , nonNullFailedItems = dataQuality.notNull(metadataDF,self.nonNullColumns)
        dqResult.append(nonNullCheckResult)
        if nonNullCheckResult == 'failed':
            print(f'Non Null Column check failed for {nonNullFailedItems}')

        # check for accepted values in schema

        schemaNameResult , invalidValues = dataQuality.columnValueCheck(metadataDF, 'schemaName', self.schemaName)
        dqResult.append(schemaNameResult)
        if schemaNameResult == 'failed':
            print(f'schemaName Column has invalid values {invalidValues}')

        # check for tableType accepted values

        tableTypeCheckResult, invalidValues = dataQuality.columnValueCheck(metadataDF, 'tableType', self.tableType)
        dqResult.append(tableTypeCheckResult)
        if tableTypeCheckResult == 'failed':
            print(f'tableType Column has invalid values {invalidValues}')

        # check for columnDataType accepted values

        columnDataTypeCheckResult, invalidValues = dataQuality.columnValueCheck(metadataDF, 'columnDataType', self.columnDataType)
        dqResult.append(columnDataTypeCheckResult)
        if columnDataTypeCheckResult == 'failed':
            print(f'columnDataType Column has invalid values {invalidValues}')

        # check for pk accepted values

        pkCheckResult, invalidValues = dataQuality.columnValueCheck(metadataDF, 'pk', self.pk)
        dqResult.append(pkCheckResult)
        if pkCheckResult == 'failed':
            print(f'pk Column has invalid values {invalidValues}')

        # check for fk accepted values

        fkCheckResult, invalidValues = dataQuality.columnValueCheck(metadataDF, 'fk', self.fk)
        dqResult.append(fkCheckResult)
        if fkCheckResult == 'failed':
            print(f'fk Column has invalid values {invalidValues}')

        # check for partitionKey accepted values

        partitionKeyCheckResult, invalidValues = dataQuality.columnValueCheck(metadataDF, 'partitionKey', self.partitionKey)
        dqResult.append(partitionKeyCheckResult)
        if partitionKeyCheckResult == 'failed':
            print(f'partitionKey Column has invalid values {invalidValues}')

        # check for nullable accepted values

        nullableCheckResult, invalidValues = dataQuality.columnValueCheck(metadataDF, 'nullable', self.nullable)
        dqResult.append(nullableCheckResult)
        if nullableCheckResult == 'failed':
            print(f'nullable Column has invalid values {invalidValues}')

        # check for dataDomains accepted values

        dataDomainCheckResult, invalidValues = dataQuality.columnValueCheck(metadataDF, 'dataDomain', self.dataDomain)
        dqResult.append(dataDomainCheckResult)
        if dataDomainCheckResult == 'failed':
            print(f'dataDomain Column has invalid values {invalidValues}')

        # check for securityClassification accepted values

        securityClassificationCheckResult, invalidValues = dataQuality.columnValueCheck(metadataDF, 'securityClassification', self.securityClassification)
        dqResult.append(securityClassificationCheckResult)
        if securityClassificationCheckResult == 'failed':
            print(f'securityClassification Column has invalid values {invalidValues}')

        # check for piiCategory accepted values

        piiCategoryCheckResult, invalidValues = dataQuality.columnValueCheck(metadataDF, 'piiCategory', self.piiCategory)
        dqResult.append(piiCategoryCheckResult)
        if piiCategoryCheckResult == 'failed':
            print(f'piiCategory Column has invalid values {invalidValues}')


        
        print(dqResult)

        if 'failed' in dqResult:
            raise Exception('Metadata did not pass DQ rules.')
        else:
            # Check if metadata already exisits
            # Read the file from Syanpse

            metadataURL = self.getURL(self.synServer,self.ceAdminDB,self.synUser)
            print("metadata URL: {}".format(metadataURL))

            synDF = self.getSynTable(metadataURL,self.metadataTableName)
            display(synDF)
            
            # Check if the metadata already Exists

            synMDF = synDF.where(synDF.md_metadataFileName == metadataFileName)
            checkCount = synMDF.count()

            if checkCount > 0:
                print(f"*****************************Metadata {metadataFileName} alreay exists *****************************************")
                dqResult.append(False)

            if False in dqResult:
                raise Exception("Identified data quality checks in metadata ")
            else:
                self.loadSynTable(metadataDF,self.metadataTableName)
                print("{} metadata loaded to Synapse Table.".format(metadataFileName))


# COMMAND ----------

sk = imMetadataIngestion()
sk.run('Squad11CustomerTower_dim_unified_customer.csv')