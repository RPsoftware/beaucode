# Databricks notebook source
# MAGIC %run /scripts/genericInfoMartModules/genericModules/genericFunctions

# COMMAND ----------

import pyspark.sql.functions as F

# COMMAND ----------

class rptCustomer:
 
    def __init__(self):
        """
        Assigning Variable from config file
        """
        # target details
        self.targetPath = "/mnt/eim/business/internal/ce/rpt/cdd_rpt_customer"

        # Source Details
        self.unified_cust = spark.read.format("delta").load("/mnt/enh/business/confidential/iddi/rdl/gb_customer_data_domain_odl/cdd_odl_unified_customer")

        self.unified_cust.createOrReplaceTempView("unified_cust")
 
    def run(self):
        print("*******************Execution Start*********************")
 
        source_df = spark.sql("SELECT unified_cust_id, registration_date, in_store_ind, single_profile_ind FROM unified_cust")

        source_df = source_df.withColumn('customer_type', F.when((F.col('in_store_ind') == 1) & (F.col('single_profile_ind') == 'N'), 'in-store only')
                                                            .when((F.col('in_store_ind') == 1) & (F.col('single_profile_ind') == 'Y'), 'SP + in-store')
                                                            .when((F.col('in_store_ind') == 0) & (F.col('single_profile_ind') == 'Y'), 'SP only')
                                                            .otherwise('NULL'))
        source_df = source_df.select("unified_cust_id", "customer_type", "registration_date", F.lit('Null').alias("channel_grocery_ind"), F.lit('Null').alias("channel_sng_ind"), F.lit('Null').alias("channel_george_ind"))

        source_df.write.mode("overwrite").format("delta").save(self.targetPath)
 
        print("************** SPARK JOB complete****************")
 
aa = rptCustomer()
aa.run()


# COMMAND ----------

df = spark.read.format("delta").load("/mnt/eim/business/internal/ce/rpt/cdd_rpt_customer")
df.createOrReplaceTempView("rpt_customer")

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(registration_date), max(registration_date) from rpt_customer

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from rpt_customer

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from rpt_customer limit 5000