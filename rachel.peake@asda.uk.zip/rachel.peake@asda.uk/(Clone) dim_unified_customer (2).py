# Databricks notebook source
#
# Customer Matching Engine (CME 1.0)
#

#Install additional libraries
%pip install pycryptodome

# COMMAND ----------

# MAGIC %run /scripts/genericInfoMartModules/genericModules/dimProcessing

# COMMAND ----------

# MAGIC %run /scripts/genericInfoMartModules/genericModules/genericFunctions
# MAGIC

# COMMAND ----------

# Importing necessary libraries
import base64
from Crypto.Cipher import AES
from pyspark.sql.types import StringType
import re
import os
import pyspark.sql.functions as F
from Crypto.Util.Padding import pad

def decrypt_val(clear_text,MASTER_KEY):
    if clear_text and clear_text != '0':
        cipher = AES.new(bytes(MASTER_KEY,'ascii'), AES.MODE_ECB)
        decodebase64 = base64.b64decode(clear_text.encode('latin-1'))
        decrypt_text = cipher.decrypt(decodebase64)
        textBase64P = decrypt_text.decode('latin-1').strip()#.encode('ascii','ignore')
        textBase64P = re.sub('[$\x00-\x09\x0b-\x0c\x0e-\x1f]', r'', str(textBase64P))
        return str(textBase64P)
 
    return clear_text
 
decrypt = F.udf(decrypt_val,StringType())

# COMMAND ----------

#from pyspark.dbutils import DBUtils

#dbutils = DBUtils(spark)
#dbutils.fs.mounts()

# COMMAND ----------

import pyspark.sql.functions as F
from pyspark.sql.types import StringType, DecimalType, LongType
from pyspark.sql.window import Window
import re

class matchingEngine:
    
    def __init__(self): 

        #spark settings 
        spark.conf.set("spark.sql.parquet.enable,summary-metadata","false") #Added for performance improvement while writing parquet file
        spark.conf.set("spark.sql.parquet.enableVectorizedReader","false") #Stopping the automatic conversion in double,decimal datatye to Binary
        
        #source path for data in rdl storage (enrich layer)
        self.sourcePath = "/mnt/enh/business/"
        
        #data
        self.cust = gf.loadDeltaFile(self.sourcePath + "confidential/iddi/rdl/gb_customer_secured_dl_tables/cust")   #bring in cust data
        self.custCard = gf.loadDeltaFile(self.sourcePath + "confidential/iddi/rdl/gb_customer_secured_dl_tables/cust_card/") #bring in cust_card data
        self.stor = gf.loadDeltaFile(self.sourcePath + "confidential/iddi/rdl/gb_mb_store_secured_dl_tables/store_visit_tender/")  #bring in store_visit_tender data 
        self.custCntct = gf.loadDeltaFile(self.sourcePath + "confidential/iddi/rdl/gb_customer_secured_dl_tables/cust_cntct") #bring in cust_cntct
        self.custAddr = gf.loadDeltaFile(self.sourcePath + "confidential/iddi/rdl/gb_customer_secured_dl_tables/cust_addr") #bring in cust_addr
        self.transaction_ids = gf.loadDeltaFile("/mnt/enh/business/internal/iddi/rdl/gb_customer_data_domain_odl/cdd_odl_transaction_ids") #bring in transaction_ids
        self.dim_customer = gf.loadDeltaFile("/mnt/eim/business/internal/infoMart/dimensions/dim_customer_v2/") #bring in dim_customer data
 
        #variables
        self.columns_to_check = ['customerid', 'source_system_id', 'title', 'first_name', 'middle_name', 'last_name', 'email_id', 'phone_nbr', 'pihash', 'xref', 'guest_order_ind', 'billing_first_name', 'billing_last_name', 'billing_address1', 'billing_address2', 'billing_address3', 'billing_address4', 'billing_address5', 'billing_address6', 'billing_city', 'billing_county', 'billing_zip_Cd', 'billing_state', 'billing_country', 'billing_address', 'latitude', 'longitude', 'blacklist', 'cbb_seen', 'version', 'source', 'ingestts', 
                                 ]

        self.email_id_column_patterns = ['%@asda1%', '%[_]automation%', 'createnew%', 'mobile_auto%', 'rishi2019%', 'qa[_]%', '%qaprod%', '%@devmail%', '%@asda1%', '%@asda2%', '%@user.com', '%sngtest%', '%@test.com', '%@jmeter.com', '%@keynote.doo', '%@sptest.com', '%@spother.com', '%sng.com', '%asif.com', '%test4.com', '%tnccheck%', '%prodcheck%', '%bsahoo%', '%asda.com', '%asdatest.com', '%keynote%', '%checkoutopt%', 'dpmigrationtest%', '%qa_spuser%', '%scanandgoqbust', '%perftest.com', '%asdatest%'
                                ]
        self.first_name_column_patterns = ['Automation%','TestFN']

        #set env variables
        self.env = os.getenv('env')
        self.loc = 'uks'
        self.instance = '01'

        ## Key Vault variables
        self.dbScope = 'kv-sa-lnd-{}-{}-{}'.format(self.env,self.loc,self.instance)
        self.secretKey = 'dbr-spn'
        self.clientId = 'spn-AppId'
        self.master_key = dbutils.secrets.get(scope='kv-sa-lnd-{}-{}-{}'.format(self.env, self.loc, self.instance), key='customer-confidential')

        ## Target table variables 
        self.targetTable = "dim_unified_customer"
        self.targetPath = "/mnt/eim/business/internal/infoMart/dimensions/dim_unified_customer"
        self.partitionList = ["source"]
        self.sk_key = "dim_unified_customer_sk"

#Function to replace blank values with null
    def replace_blank_with_null(self,df,columns_to_check):
        new_df = df.select([F.when(F.col(column) == '', None).otherwise(F.col(column)).alias(column) for column in columns_to_check])
        return new_df

#Function to filter out the test data before matching
    def filter_test_data(self,df, email_column,email_column_patterns,first_name_column,first_name_column_patterns):
        remaining_df = df
        email_condition = df[email_column].rlike('|'.join(email_column_patterns))
        first_name_condition = df[first_name_column].rlike('|'.join(first_name_column_patterns))
        matched_data = df.filter(email_condition | first_name_condition)
        remaining_df = remaining_df.subtract(matched_data)
        return matched_data, remaining_df

#Function to convert sql wildcard to python regular expression for removing test data since we are using python
    def sql_list_to_regex_list(self,sql_list):
        regex_exp_list = [re.sub(r"%",".*",expr) for expr in sql_list]
        regex_exp_list = [re.sub(r"_",".",expr) for expr in regex_exp_list]
        return regex_exp_list   

#Decrypt fields before linkage
        # store_visit_tender
    def decrypt_cols(self, df):
            
        piiColumnList = [['customer-confidential',['xref']]]
        piiDBScope = 'kv-sa-lnd-prod-uks-01'
        columnList = df.columns

        ddf = df 
        for key,columnlist in piiColumnList:
                encryptionKey = self.master_key
                for column in columnlist:
                        ddf = ddf.withColumn(column,decrypt(str(column), F.lit(encryptionKey)))
        dfnew = ddf.select(*columnList)
        #display(dfnew)
        return(dfnew)

    def run(self):
        
        self.stor = (self.stor.select('acct_nbr', 'tndr_type_cd', 'upd_ts')
                     .filter(F.col('tndr_type_cd') == 8)
                     .withColumn('acct_nbr', F.trim(F.col('acct_nbr')))
                     .distinct())
        self.custCard = (self.custCard.select('pymt_token_txt', 'ref_id', 'gdpr_del_ind', 'cust_del_ind', 'singl_profl_id')
                         .filter((F.col('gdpr_del_ind')== 0) & (F.col('cust_del_ind') ==0) )
                         .withColumn('pymt_token_txt', F.trim(F.col('pymt_token_txt')))
                         .withColumn('ref_id', F.col('ref_id').cast(LongType()))
                         .distinct())       

        self.cust.createOrReplaceTempView("cust")
        self.custCard.createOrReplaceTempView("custCard")
        self.stor.createOrReplaceTempView('stor')
        self.custCntct.createOrReplaceTempView("custCntct")
        self.custAddr.createOrReplaceTempView("custAddr")

  
        #spark sql joins
        sp="""select '' as customerid
                        ,cust.singl_profl_id as source_system_id 
                        ,lower(trim(cust.title_cd)) as title, lower(replace(replace(replace(trim(cust.first_nm),'-',''),'\"',''),'''','')) as first_name 
                        ,cust.mid_nm as middle_name
                        ,lower(replace(replace(replace(trim(cust.last_nm),'-',''),'\"',''),'''','')) As last_name 
                        ,lower(trim(cust.email_id)) as email_id 
                        ,COALESCE(trim(cntct.cntct_nm)
                        ,trim(cust.scndry_login_id)) as phone_nbr
                        ,trim(cr.pymt_token_txt) as pihash
                        ,trim(cr.ref_id) as xref
                        ,cust.guest_ind as guest_order_ind
                        ,lower(trim(adr.first_nm)) as billing_first_name,lower(trim(adr.last_nm)) as billing_last_name 
                        ,lower(trim(adr.addr_line_1_txt)) as billing_address1
                        ,lower(trim(adr.addr_line_2_txt)) as billing_address2 
                        ,lower(trim(adr.addr_line_3_txt)) as  billing_address3
                        ,'' as billing_address4
                        ,'' as billing_address5
                        ,'' as billing_address6 
                        ,lower(trim(adr.city_nm)) as billing_city
                        ,'' as billing_county
                        ,lower(trim(adr.post_cd)) as billing_zip_Cd
                        ,lower(trim(adr.st_nm)) as billing_state
                        ,lower(trim(adr.cntry_cd)) as billing_country
                        ,lower(trim(adr.fmt_addr_txt)) as billing_address
                        ,adr.lat_dgr as latitude
                        ,adr.long_dgr as longitude
                        ,'' as blacklist
                        ,'' as cbb_seen
                        ,'' as version
                        ,lower(cust.data_src_cd) as source
                        ,IFNULL((DATE_FORMAT(cust.ingest_ts,'yyyyMMdd')),999999) as ingestts 
                from (select singl_profl_id,title_cd,first_nm,last_nm,mid_nm,email_id,guest_ind,data_src_cd,ingest_ts, scndry_login_id
                        from cust where gdpr_del_ind=0 ) cust 
                left join (select cntct_nm,singl_profl_id 
                        from custCntct 
                        where cntct_type_nm ='PHONE' and gdpr_del_ind=0 and cust_del_ind=0) cntct 
                on cust.singl_profl_id=cntct.singl_profl_id 
                left join (select singl_profl_id,pymt_token_txt,ref_id 
                        from custCard 
                        ) cr 
                on cust.singl_profl_id=cr.singl_profl_id 
                left join (select singl_profl_id, first_nm, last_nm, addr_line_1_txt, addr_line_2_txt, addr_line_3_txt, city_nm, post_cd, st_nm, cntry_cd,      
                                fmt_addr_txt, lat_dgr, long_dgr 
                        from custAddr  
                        where gdpr_del_ind=0 and cust_del_ind=0 and (addr_usag_type_nm IS NULL or addr_usag_type_nm='shipTo')) adr
                on cust.singl_profl_id=adr.singl_profl_id """

        sp = spark.sql(sp).dropDuplicates()
        #sp.show(25)

        #create store data df
        storeExtract="""select '' as customerid
                                ,stor.acct_nbr as source_system_id
                                ,null as title
                                ,null as first_name
                                ,null as middle_name
                                ,null As last_name
                                ,null as email_id
                                ,null as phone_nbr
                                ,cr.pymt_token_txt as pihash
                                ,stor.acct_nbr as xref
                                ,null as guest_order_ind
                                ,null as billing_first_name
                                ,null as billing_last_name
                                ,null as billing_address1
                                ,null as billing_address2
                                ,null as  billing_address3
                                ,null as billing_address4
                                ,null as billing_address5
                                ,null as billing_address6
                                ,null as billing_city
                                ,null as billing_county
                                ,null as billing_zip_Cd
                                ,null as billing_state
                                ,null as billing_country
                                ,null as billing_address
                                ,null as latitude
                                ,null as longitude
                                ,null as blacklist
                                ,null as cbb_seen
                                ,null as version
                                ,'store' as source
                                ,IFNULL((DATE_FORMAT(upd_ts, 'yyyyMMdd')),999999) as partkey 
                        from (select acct_nbr,max(upd_ts) as upd_ts  
                                from stor    
                                group by acct_nbr) stor 
                        full outer join (select pymt_token_txt, ref_id 
                                        from custCard) cr 
                        on stor.acct_nbr = cr.ref_id """

        storeExtract = spark.sql(storeExtract).dropDuplicates()
        #storeExtract.show(20)

        unionDF = sp.unionAll(storeExtract)
        
        #Replacing blank values with null
        df_intData_trans = self.replace_blank_with_null(unionDF,self.columns_to_check)
        df_intData_trans = self.decrypt_cols(df_intData_trans)
        
        #replacing the leading 0's in xref for a proper match
        df_intData = unionDF.withColumn('xref',F.regexp_replace(F.col('xref'),'^0+',''))
        
        #test data removal to get the data frame free of unwanted test data
        email_id_column_patterns_formatted = self.sql_list_to_regex_list(self.email_id_column_patterns)
        first_name_column_patterns_formatted = self.sql_list_to_regex_list(self.first_name_column_patterns)
        test_data_frame,init_customer_data_frame = self.filter_test_data(df_intData_trans,'email_id',email_id_column_patterns_formatted,'first_name', first_name_column_patterns_formatted)

        # Changing Datatype of UCID from String to Long 
        final_customer_data_frame = init_customer_data_frame.withColumn("customerid",F.col("customerid").cast("long"))
        
        #final_customer_data_frame.write.mode("overwrite").parquet("/mnt/raw/matchingEngine/gbTablesData/unifiedRawData/CME/#unified_customer_table_L1.parquet")

        # Applying axiomatic rules
        window_spec_ordering = Window.orderBy("source")
        df = final_customer_data_frame.withColumn("row_number",F.row_number().over(window_spec_ordering))
        max_id = "10000000000000000000"
        max_id = (F.lit(max_id)).cast(DecimalType(20, 0))
        df = df.withColumn("customerid",max_id-F.col("row_number").cast(DecimalType(20, 0)))
        df = df.drop("row_number")
        
        #Window specification for rules
        window_spec_0 = Window.partitionBy("source_system_id").orderBy(F.col('customerid').isNull().cast('int'))
        window_spec_1 = Window.partitionBy("first_name","last_name","email_id").orderBy(F.col('customerid').isNull().cast('int'))
        window_spec_2 = Window.partitionBy("first_name","last_name","phone_nbr").orderBy(F.col('customerid').isNull().cast('int'))
        window_spec_3 = Window.partitionBy("first_name","last_name","billing_address").orderBy(F.col('customerid').isNull().cast('int'))
        window_spec_4 = Window.partitionBy("first_name","last_name","xref").orderBy(F.col('customerid').isNull().cast('int'))
        window_spec_5 = Window.partitionBy("xref").orderBy(F.col('customerid').isNull().cast('int'))

        #Assign min unique id with each group
        df_w1 = df.withColumn("max_customerid",F.max("customerid").over(window_spec_0))
        df_w1 = df_w1.withColumn("customerid", F.when(F.col('source_system_id').isNotNull(),F.col("max_customerid")).otherwise(F.col('customerid'))).drop("max_customerid")

        df_w2 = df_w1.withColumn("max_customerid",F.max("customerid").over(window_spec_1))
        df_w2 = df_w2.withColumn("customerid", F.when((F.col('first_name').isNotNull()) & (F.col('last_name').isNotNull()) & (F.col('email_id').isNotNull()),F.col("max_customerid")).otherwise(F.col('customerid'))).drop("max_customerid")

        df_w3 = df_w2.withColumn("max_customerid",F.max("customerid").over(window_spec_2))
        df_w3 = df_w3.withColumn("customerid", F.when((F.col('first_name').isNotNull()) & (F.col('last_name').isNotNull()) & (F.col('phone_nbr').isNotNull()),F.col("max_customerid")).otherwise(F.col('customerid'))).drop("max_customerid")

        df_w4 = df_w3.withColumn("max_customerid",F.max("customerid").over(window_spec_3))
        df_w4 = df_w4.withColumn("customerid", F.when((F.col('first_name').isNotNull()) & (F.col('last_name').isNotNull()) & (F.col('billing_address').isNotNull()) & (~F.col('billing_address').startswith('dummy')) & (~F.col('billing_address').contains('dummy')),F.col("max_customerid")).otherwise(F.col('customerid'))).drop("max_customerid")

        df_w5 = df_w4.withColumn("max_customerid",F.max("customerid").over(window_spec_4))
        df_w5 = df_w5.withColumn("customerid", F.when((F.col('first_name').isNotNull()) & (F.col('last_name').isNotNull()) & (F.col('xref').isNotNull()),F.col("max_customerid")).otherwise(F.col('customerid'))).drop("max_customerid")

        res_df = df_w5.withColumn("max_customerid",F.max("customerid").over(window_spec_5))
        res_df = res_df.withColumn("customerid",F.when((F.col('xref').isNotNull()) & (F.col('source') == 'store'),F.col("max_customerid")).otherwise(F.col('customerid'))).drop("max_customerid")

        # Column attached to check the rule applied(Still in progress)
        final_df =res_df.withColumn("matched",F.when(((F.count("*").over(window_spec_1)>1) & F.col('customerid').isNotNull() & (F.col('first_name').isNotNull()) & (F.col('last_name').isNotNull()) & (F.col('email_id').isNotNull())),"R1").otherwise(None))

        final_df =final_df.withColumn("matched",F.when(((F.count("*").over(window_spec_2)>1) & F.col('customerid').isNotNull() & (F.col('first_name').isNotNull()) & (F.col('last_name').isNotNull()) & (F.col('phone_nbr').isNotNull())),F.when(final_df["matched"].isNull(),"R2").otherwise(F.concat(final_df["matched"],F.lit("R2")))))

        final_df =final_df.withColumn("matched",F.when(((F.count("*").over(window_spec_3)>1) & F.col('customerid').isNotNull() & (F.col('first_name').isNotNull()) & (F.col('last_name').isNotNull()) & (F.col('billing_address').isNotNull())),F.when(final_df["matched"].isNull(),"R3").otherwise(F.concat(final_df["matched"],F.lit("R3")))))

        final_df =final_df.withColumn("matched",F.when(((F.count("*").over(window_spec_4)>1) & F.col('customerid').isNotNull() & (F.col('first_name').isNotNull()) & (F.col('last_name').isNotNull()) & (F.col('xref').isNotNull())),F.when(final_df["matched"].isNull(),"R4").otherwise(F.concat(final_df["matched"],F.lit("R4")))))

        final_df =final_df.withColumn("matched",F.when(((F.count("*").over(window_spec_5)>1) & F.col('customerid').isNotNull() & (F.col('xref').isNotNull())),F.when(final_df["matched"].isNull(),"R5").otherwise(F.concat(final_df["matched"],F.lit("R5")))))

        final_df =final_df.withColumn("matched",F.when(((F.count("*").over(window_spec_0)>1) & F.col('customerid').isNotNull() & (F.col('source_system_id').isNotNull())),F.when(final_df["matched"].isNull(),"R0").otherwise(F.concat(final_df["matched"],F.lit("R0")))))

        final_df = final_df.withColumn("customerid", F.concat(F.lit('U-'),F.col("customerid").cast("string"))).withColumn("cbb_seen",F.date_format(F.current_timestamp(),"yyyy-MM-dd HH:mm:ss")).withColumn("version",F.date_format(F.current_timestamp(),"yyyyMMddHHmm"))
        
        #final_df.write.mode("overwrite").parquet("/mnt/raw/matchingEngine/gbTablesData/unifiedRawData/CME/unified_customer_table_L2.parquet")
        
        #joining TRANSACTION_IDS to fetch worldline token id 
        #Sample data contains one day of data for 22nd May 2024.
        trans_ids_filtered = self.transaction_ids.select("lead_xref", "lead_token_id", "singl_profl_id")
        trans_ids_filtered = trans_ids_filtered.withColumn('singl_profl_id',F.regexp_replace(F.col('singl_profl_id'),'^0+',''))

        #join unified_customer with transaction ids on xref = xref to fetch worldline token id.
        uc_ti_join = final_df.join(trans_ids_filtered, on=[trans_ids_filtered.lead_xref == final_df.xref], how="LEFT").drop(trans_ids_filtered.lead_xref)

        #join dim_customer to fetch crm id 
        dim_customer_filtered = self.dim_customer.select(F.col("bk_crm_customer_id"), F.col("bk_singl_profl_id"))
        
        uc_ti_cust = uc_ti_join.join(dim_customer_filtered, on=[dim_customer_filtered.bk_singl_profl_id == uc_ti_join.singl_profl_id], how='LEFT')
        
        #surrogate key 
        uc_ti_cust = uc_ti_cust.withColumn("dim_unified_customer_sk", F.lit("0").cast("int"))

        #pre_df = gf.process_surrogate_key(self.targetPath, uc_ti_cust, self.sk_key)
        
        final_df = (uc_ti_cust
                        .select(F.col("dim_unified_customer_sk")
                        ,F.col("customerid")
                        ,F.col("source_system_id")
                        ,F.col("title")
                        ,F.col("first_name")
                        ,F.col("middle_name")
                        ,F.col("last_name")
                        ,F.col("email_id")
                        ,F.col("phone_nbr")
                        ,F.col("pihash")
                        ,F.col("xref")
                        ,F.col("guest_order_ind")
                        ,F.col("billing_first_name")
                        ,F.col("billing_last_name")
                        ,F.col("billing_address1")
                        ,F.col("billing_address2")
                        ,F.col("billing_address3")
                        ,F.col("billing_address4")
                        ,F.col("billing_address5")
                        ,F.col("billing_address6")
                        ,F.col("billing_city")
                        ,F.col("billing_county")
                        ,F.col("billing_zip_Cd")
                        ,F.col("billing_state")
                        ,F.col("billing_country")
                        ,F.col("billing_address")
                        ,F.col("latitude")
                        ,F.col("longitude")
                        ,F.col("blacklist")
                        ,F.col("cbb_seen")
                        ,F.col("version")
                        ,F.col("source")
                        ,F.col("ingestts")
                        ,F.col("matched")
                        ,F.col("lead_token_id")
                        ,F.col("singl_profl_id")
                        ,F.col("bk_crm_customer_id"))
        )
        
        #write out to storage account
        #dimProcessing.type1Delta1(self.targetPath, self.targetTable,final_df, self.partitionList, self.sk_key)
        final_df = final_df.distinct()
        final_df.write.mode("overwrite").format("delta").save(self.targetPath)
        
aa = matchingEngine()
aa.run()

# COMMAND ----------

duc = spark.read.format("delta").load("/mnt/eim/business/internal/infoMart/dimensions/dim_unified_customer")
duc.createOrReplaceTempView("duc")

tids = spark.read.format("delta").load("/mnt/stg/business/internal/iddi/rdl/gb_customer_data_domain_odl/cdd_odl_transaction_ids")
tids.createOrReplaceTempView("tids")

dcust = spark.read.format("delta").load("/mnt/eim/business/internal/infoMart/dimensions/dim_customer_v2/")
dcust.createOrReplaceTempView("dcust")

custCard = spark.read.format("delta").load("/mnt/stg/business/confidential/iddi/rdl/gb_customer_secured_dl_tables/cust_card/")
custCard.createOrReplaceTempView("custCard") 

svt_stg = spark.read.format("delta").load("/mnt/stg/business/confidential/iddi/rdl/gb_mb_store_secured_dl_tables/store_visit_tender/")
svt_stg.createOrReplaceTempView("svt_stg")

svt_enh = spark.read.format("delta").load("/mnt/enh/business/confidential/iddi/rdl/gb_mb_store_secured_dl_tables/store_visit_tender/")
svt_enh.createOrReplaceTempView("svt_enh")

sourcePath = "/mnt/stg/business/"
cust = spark.read.format("delta").load("/mnt/stg/business/confidential/iddi/rdl/gb_customer_secured_dl_tables/cust") 
cust.createOrReplaceTempView("cust")
custCntct = spark.read.format("delta").load("/mnt/stg/business/confidential/iddi/rdl/gb_customer_secured_dl_tables/cust_cntct")
custCntct.createOrReplaceTempView("custCntct") 
custAddr = spark.read.format("delta").load("/mnt/stg/business/confidential/iddi/rdl/gb_customer_secured_dl_tables/cust_addr") 
custAddr.createOrReplaceTempView("custAddr") 

#first_df_base = spark.read.format("parquet").load("/mnt/raw/matchingEngine/gbTablesData/unifiedRawData/CME/unified_customer_table_L1.parquet")


# COMMAND ----------

# MAGIC %sql
# MAGIC select ref_id from custcard

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*), count(ref_id), count(distinct(ref_id))
# MAGIC  from (select singl_profl_id,title_cd,first_nm,last_nm,mid_nm,email_id,guest_ind,data_src_cd,ingest_ts, scndry_login_id
# MAGIC                         from cust where gdpr_del_ind=0 ) cust 
# MAGIC                 left join (select cntct_nm,singl_profl_id 
# MAGIC                         from custCntct 
# MAGIC                         where cntct_type_nm ='PHONE' and gdpr_del_ind=0 and cust_del_ind=0) cntct 
# MAGIC                 on cust.singl_profl_id=cntct.singl_profl_id 
# MAGIC                 left join (select singl_profl_id,pymt_token_txt,ref_id 
# MAGIC                         from custCard 
# MAGIC                         where gdpr_del_ind=0  and cust_del_ind=0) cr 
# MAGIC                 on cust.singl_profl_id=cr.singl_profl_id 
# MAGIC                 left join (select singl_profl_id, first_nm, last_nm, addr_line_1_txt, addr_line_2_txt, addr_line_3_txt, city_nm, post_cd, st_nm, cntry_cd,      
# MAGIC                                 fmt_addr_txt, lat_dgr, long_dgr 
# MAGIC                         from custAddr  
# MAGIC                         where gdpr_del_ind=0 and cust_del_ind=0 and (addr_usag_type_nm IS NULL or addr_usag_type_nm='shipTo')) adr
# MAGIC                 on cust.singl_profl_id=adr.singl_profl_id;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE or replace TEMPORARY VIEW ref_id_list
# MAGIC as
# MAGIC select distinct ref_id
# MAGIC  from (select singl_profl_id,title_cd,first_nm,last_nm,mid_nm,email_id,guest_ind,data_src_cd,ingest_ts, scndry_login_id
# MAGIC                         from cust where gdpr_del_ind=0 ) cust 
# MAGIC                 left join (select cntct_nm,singl_profl_id 
# MAGIC                         from custCntct 
# MAGIC                         where cntct_type_nm ='PHONE' and gdpr_del_ind=0 and cust_del_ind=0) cntct 
# MAGIC                 on cust.singl_profl_id=cntct.singl_profl_id 
# MAGIC                 left join (select singl_profl_id,pymt_token_txt,ref_id 
# MAGIC                         from custCard 
# MAGIC                         where gdpr_del_ind=0  and cust_del_ind=0) cr 
# MAGIC                 on cust.singl_profl_id=cr.singl_profl_id 
# MAGIC                 left join (select singl_profl_id, first_nm, last_nm, addr_line_1_txt, addr_line_2_txt, addr_line_3_txt, city_nm, post_cd, st_nm, cntry_cd,      
# MAGIC                                 fmt_addr_txt, lat_dgr, long_dgr 
# MAGIC                         from custAddr  
# MAGIC                         where gdpr_del_ind=0 and cust_del_ind=0 and (addr_usag_type_nm IS NULL or addr_usag_type_nm='shipTo')) adr
# MAGIC                 on cust.singl_profl_id=adr.singl_profl_id;

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*), count(distinct acct_nbr), count(acct_nbr)
# MAGIC     from (select trim(acct_nbr) as acct_nbr,max(upd_ts) as upd_ts  
# MAGIC             from svt
# MAGIC             where tndr_type_cd=8   
# MAGIC             group by trim(acct_nbr)) stor 
# MAGIC     full outer join (select trim(pymt_token_txt) as pymt_token_txt,try_cast(ref_id as bigint) ref_id 
# MAGIC                     from custCard 
# MAGIC                     where gdpr_del_ind=0  and cust_del_ind=0) cr 
# MAGIC     on stor.acct_nbr = cr.ref_id 

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from xref_list full outer join ref_id_list on ref_id = acct_nbr
# MAGIC where ref_id is null or acct_nbr is null 

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*), count(acct_nbr), count(distinct acct_nbr)
# MAGIC                         from (select trim(acct_nbr) as acct_nbr,max(upd_ts) as upd_ts  
# MAGIC                                 from svt
# MAGIC 								                where tndr_type_cd=8   
# MAGIC                                 group by trim(acct_nbr)) stor 
# MAGIC                         full outer join (select trim(pymt_token_txt) as pymt_token_txt,try_cast(ref_id as bigint) ref_id 
# MAGIC                                         from custCard 
# MAGIC 										                    where gdpr_del_ind=0  and cust_del_ind=0) cr 
# MAGIC                         on stor.acct_nbr = cr.ref_id 

# COMMAND ----------

print("in final table would expect to see ", 315208214 + 17333962, "xrefs, but we have ",  )

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*), count(lead_xref), count(distinct lead_xref), count(lead_token_id), count(distinct lead_token_id), count(singl_profl_id), count(distinct singl_profl_id)
# MAGIC from tids

# COMMAND ----------

first_df_base.createOrReplaceTempView("L1")


# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*), count(xref) from L1

# COMMAND ----------

# MAGIC %sql
# MAGIC select ref_id
# MAGIC from custCard where gdpr_del_ind = 0 and cust_del_ind = 0 and ref_id is not null

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*), count(xref), count(distinct xref), count(lead_token_id), count(distinct lead_token_id), count(bk_crm_customer_id), count(distinct bk_crm_customer_id) from duc;
# MAGIC --select lead_token_id from duc where lead_token_id is not null 

# COMMAND ----------

# MAGIC %sql
# MAGIC --select len(xref), count(*) from duc group by len(xref)
# MAGIC select * from duc where len(xref) > 10

# COMMAND ----------

# MAGIC %sql
# MAGIC select xref, lead_token_id from duc where lead_token_id is not null limit 50

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from ((
# MAGIC select distinct lead_xref, visit_dt from tids) og left join (
# MAGIC select distinct xref from duc ) jn on og.lead_xref = jn.xref ) a
# MAGIC where a.xref is null and visit_dt = '2023-09-04'

# COMMAND ----------

# MAGIC %sql
# MAGIC select visit_dt, count(distinct lead_xref)
# MAGIC from ((
# MAGIC select distinct lead_xref, visit_dt from tids) og left join (
# MAGIC select distinct xref from duc ) jn on og.lead_xref = jn.xref ) a
# MAGIC where a.xref is null
# MAGIC group by visit_dt
# MAGIC having count(distinct a.lead_xref) > 0 
# MAGIC order by visit_dt asc

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct lead_xref from tids where lead_xref not in (select distinct xref from duc)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from svt_stg where trim(acct_nbr) in ( '157786859619', '157786856391',
# MAGIC '157786839579',
# MAGIC '157786855492',
# MAGIC '157786858264',
# MAGIC '157786854586',
# MAGIC '157786860625',
# MAGIC '157785502475',
# MAGIC '157786874840',
# MAGIC '157786860971',
# MAGIC '157786859650',
# MAGIC '157786853844');
# MAGIC
# MAGIC %sql
# MAGIC select distinct trim(acct_nbr) from svt_stg where visit_dt = '2023-09-04' and tndr_type_cd = 8;
# MAGIC --regexp_replace(trim(acct_nbr), '^0+','') like '%157786859619%'
# MAGIC
# MAGIC %sql
# MAGIC select count(distinct acct_nbr) from svt_enh where acct_nbr !='' and visit_dt = '2023-09-04'; --1787576
# MAGIC %sql
# MAGIC select count(distinct acct_nbr) from svt_stg where acct_nbr is not null and visit_dt = '2023-09-04'; 1787577
# MAGIC
# MAGIC %sql
# MAGIC select * from custCard where ref_id in ( '157786859619', '157786856391',
# MAGIC '157786839579',
# MAGIC '157786855492',
# MAGIC '157786858264',
# MAGIC '157786854586',
# MAGIC '157786860625',
# MAGIC '157785502475',
# MAGIC '157786874840',
# MAGIC '157786860971',
# MAGIC '157786859650',
# MAGIC '157786853844');

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from svt where regexp_replace(trim(acct_nbr), '^0+','') in ('100728581792',
# MAGIC '103466098508',
# MAGIC '104653625616',
# MAGIC '105598981386',
# MAGIC '106650675619',
# MAGIC '10665509161',
# MAGIC '109408640083',
# MAGIC '110536590901',
# MAGIC '110571930178',
# MAGIC '110898776049',
# MAGIC '111068266050',
# MAGIC '111177230930',
# MAGIC '111423690093',
# MAGIC '111550439389',
# MAGIC '111585049518')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from tids where lead_xref in ('100728581792',
# MAGIC '103466098508',
# MAGIC '104653625616',
# MAGIC '105598981386',
# MAGIC '106650675619',
# MAGIC '10665509161',
# MAGIC '109408640083',
# MAGIC '110536590901',
# MAGIC '110571930178',
# MAGIC '110898776049',
# MAGIC '111068266050',
# MAGIC '111177230930',
# MAGIC '111423690093',
# MAGIC '111550439389',
# MAGIC '111585049518')

# COMMAND ----------

# MAGIC %sql
# MAGIC select visit_dt, count(distinct acct_nbr) from svt where tndr_type_cd = 8 group by visit_dt order by visit_dt asc