# Databricks notebook source
# MAGIC %run /scripts/genericInfoMartModules/genericModules/genericFunctions

# COMMAND ----------

# Importing necessary libraries
import pyspark.sql.functions as F
import datetime as dt
import pyspark.sql.types
from pyspark.sql.functions import date_format
from pyspark.sql.types import IntegerType, StringType
from dateutil.relativedelta import *
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import base64


# COMMAND ----------

    
def encrypt_values (clear_text, master_key):
    if clear_text:
        cipher = AES.new(bytes(master_key, 'ascii'), AES.MODE_ECB)
        cipher_text = cipher.encrypt(pad(str(clear_text).encode("UTF-8"), AES.block_size))
        textBase64 = base64.b64encode(cipher_text)
        textBase64P = textBase64.decode('UTF-8')
        return textBase64P
    return clear_text

# COMMAND ----------

class rptCustBasket:
    def __init__(self):
        """
        Assigning Variable from config file
        """
        # Target Table
        self.targetPath = "/mnt/eim/business/internal/ce/rpt/cdd_rpt_customer_basket"

        self.odl_cus_basket = gf.loadDeltaFile("/mnt/eim/business/internal/ce/odl/cdd_odl_customer_basket")
        self.odl_cus_basket.createOrReplaceTempView("odl_basket")
        
        self.encrypt_columns = ['unified_cust_id', 'wallet_id','lead_xref']

        ## Key Vault variables
        self.dbScope = 'kv-sa-lnd-prod-uks-01'

    def run(self):
 
        cb_df = spark.sql(''' SELECT unified_cust_id, basket_id, channel_id, visit_dt, wallet_id, lead_xref, trans_type, cip_rptg_ind
                                FROM odl_basket
                               WHERE ((unified_cust_id is not null and wallet_id is not null) or
                                     (unified_cust_id is not null and wallet_id is null) or
                                     (unified_cust_id is null and wallet_id is not null))''')
 
        cb_df.repartition("visit_dt")
        
        encryptionKey = dbutils.preview.secret.get(scope = self.dbScope, key = "{}".format('customer-secret'))
        encrypt = udf(encrypt_values, StringType())
        for column in self.encrypt_columns:
            cb_df = cb_df.withColumn(column,encrypt(str(column), F.lit(encryptionKey)))            
        
        #cb_df.display()

        cb_df.write.mode("overwrite").partitionBy("visit_dt").option("overwriteSchema", "true").format("delta").save(self.targetPath)

    
ts = rptCustBasket()
ts.run()

# COMMAND ----------

cb = spark.read.format("delta").load("/mnt/eim/business/internal/ce/rpt/cdd_rpt_customer_basket")
cb.createOrReplaceTempView("cb_rpt")


# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from cb_rpt 
# MAGIC -- where unified_cust_id is not null -- 1974401136
# MAGIC -- where unified_cust_id is null --60311379
# MAGIC -- where wallet_id is null --1577606849
# MAGIC -- where wallet_id is null and unified_cust_id is not null --1577606849
# MAGIC -- where unified_cust_id is null and wallet_id is not null -- 60311379
# MAGIC where unified_cust_id is not null and wallet_id is not null --396794287
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select min(visit_dt), max(visit_dt) from cb_rpt 

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from cb_rpt