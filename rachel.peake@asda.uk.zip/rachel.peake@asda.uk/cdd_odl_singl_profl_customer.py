# Databricks notebook source
# MAGIC %run /scripts/genericInfoMartModules/genericModules/genericFunctions

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number

# COMMAND ----------


class singl_profl_customer:
 
    def __init__(self):
        """
        Assigning Variable from config file
        """
        # input tables
        self.raw_uc = spark.read.format("delta").load("/mnt/eim/business/internal/ce/raw/cdd_raw_unified_customer")
        self.sources = ['sp', 'store']
        self.ucid_latest = (self.raw_uc
                            .select(F.col("source_system_id"), F.col("source"), F.col("customerid"), F.col("version"), F.col("version_date"))
                            .filter(F.col("source").isin(self.sources))).repartition("version_date")

        # Get latest version of customerid
        self.latest_version = self.ucid_latest.agg(F.max('version')).collect()[0][0]
        self.filtered_uc = self.ucid_latest.where(self.ucid_latest.version == self.latest_version)
        self.filtered_uc.createOrReplaceTempView("filtered_uc")
        print("count of ucids before join: ", self.filtered_uc.count())

        
        self.dim_cust = spark.read.format("delta").load("/mnt/eim/business/internal/infoMart/dimensions/dim_customer_v2/")
        self.dim_cust.createOrReplaceTempView("dim_cust")

        self.cust_ucid = spark.sql("""select uc.customerid as unified_cust_id, dc.* 
                                   from filtered_uc uc
                                   left join dim_cust dc
                                   on uc.source_system_id = dc.bk_singl_profl_id """)
        self.cust_ucid.createOrReplaceTempView("cust_ucid")

        self.cust_agg_attr = spark.read.format("delta").load("/mnt/enh/business/internal/iddi/rdl/gb_mb_secured_aggregate_dl_tables/cust_agg_attr/")
        self.cust_agg_attr.createOrReplaceTempView("cust_agg_attr")

        self.ghs_user = spark.read.format("delta").load("/mnt/enh/business/internal/iddi/rdl/gb_customer_secured_dl_tables/ghs_user/")
        self.ghs_user.createOrReplaceTempView("ghs_user")

        self.loyalty_acct = spark.read.format("delta").load("/mnt/enh/business/internal/iddi/rdl/gb_customer_data_domain_odl/cdd_odl_loyalty_acct/")
        self.loyalty_acct.createOrReplaceTempView("loyalty_acct")
 
        # output tables
        self.target_table = "/mnt/eim/business/internal/ce/odl/cdd_odl_singl_profl_customer"
 
    def run(self):
        print("****************Execution Start****************")
        # single_profile
        df_sp = spark.sql("""select unified_cust_id, bk_singl_profl_id as singl_profl_id
                                        ,first_name as first_nm
                                        ,email
                                        ,secondary_loginid as scndry_login_id
                                        ,account_status
                                        ,prefix
                                        ,last_name as last_nm
                                        ,is_guest_customer as guest_ind
                                        , registration_date
                                        , date_of_birth
                                        , suspend_status
                                        , suspend_reason
                                        ,suspend_start_date as suspend_ts
                                        ,updated_date as upd_ts
                                        ,registration_channel as reg_channel
                                        from cust_ucid""")
 
        df_ghs_user = spark.sql("select user_id as atg_customer_id, singl_profl_id as user_singl_profl_id from ghs_user")
 
        df_loyalty_acct = spark.sql("select wallet_id, singl_profl_id as user_loyalty_singl_profl_id  from loyalty_acct")
 
 
        # fetch all data from customer aggregate attribute table into data frame to filter later
        df_aggr = spark.sql('''select measure_nm, channel_cd, singl_profl_userid, measure_val
                                         from cust_agg_attr''')
 
        # AGGR: tnc_accepted_at_Loyalty
        df_tnc_lty = df_aggr.filter((F.col("measure_nm") == "TNC_ACCEPTED_DATE") & (F.col("channel_cd") == "LOYALTY")) \
            .select(F.col('singl_profl_userid').alias('tnc_lty_singl_profl_userid'),
                    F.col('measure_val').alias('tnc_accepted_at_loyalty'))
 
        # AGGR: Registration Channel
        df_reg_chn = spark.sql('''select registration_channel, reg_chn_singl_profl_userid
                                         from
                                            (select measure_nm, channel_cd as registration_channel, singl_profl_userid as reg_chn_singl_profl_userid, measure_val
                                            , ROW_NUMBER() over (partition by singl_profl_userid   order by measure_val desc) rn
                                            from cust_agg_attr where measure_nm = 'REGISTRATION_CHANNEL'
                                            ) cust_ucid
                                            where rn=1''')
 
 
        # AGGR: tnc_accepted_at_grocery
        df_tnc_gcy = df_aggr.filter((F.col("measure_nm") == 'TNC_ACCEPTED_DATE') & (F.col("channel_cd") == 'GHS')) \
            .select(F.col('singl_profl_userid').alias('tnc_gcy_userid'),
                    F.col('measure_val').alias('tnc_accepted_at_grocery'))
 
        # AGGR: tnc_accepted_at_sng_kiosk
        df_tnc_kiosk = df_aggr.filter(
            (F.col("measure_nm") == "TNC_ACCEPTED_DATE") & (F.col("channel_cd") == "SNGKIOSK")) \
            .select(F.col('singl_profl_userid').alias('tnc_kiosk_userid'),
                    F.col('measure_val').alias('tnc_accepted_at_sng_kiosk'))
 
        # AGGR: tnc_accepted_at_sng_mobile
        df_tnc_mobile = df_aggr.filter(
            (F.col("measure_nm") == "TNC_ACCEPTED_DATE") & (F.col("channel_cd") == "SNGMOBILE")) \
            .select(F.col('singl_profl_userid').alias('tnc_mobile_userid'),
                    F.col('measure_val').alias('tnc_accepted_at_sng_mobile'))
 
        # AGGR: tnc_accepted_at_george
        df_tnc_george = df_aggr.filter(
            (F.col("measure_nm") == "TNC_ACCEPTED_DATE") & (F.col("channel_cd") == "GEORGE")) \
            .select(F.col('singl_profl_userid').alias('tnc_george_userid'),
                    F.col('measure_val').alias('tnc_accepted_at_george'))
        # AGGR: tnc_accepted_at_btc
        df_tnc_btc = df_aggr.filter(
           (F.col("measure_nm") == "TNC_ACCEPTED_DATE") & (F.col("channel_cd") == "BTC")) \
           .select(F.col('singl_profl_userid').alias('tnc_btc_userid'))
                   #F.col('measure_val').alias('tnc_accepted_at_btc'))
        df_tnc_btc = df_tnc_btc.withColumn("tnc_accepted_at_btc", F.lit(""))
 
        # AGGR: tnc_accepted_at_giftcards
        df_tnc_giftcards = df_aggr.filter(
            (F.col("measure_nm") == "TNC_ACCEPTED_DATE") & (F.col("channel_cd") == "GIFTCARDS")) \
            .select(F.col('singl_profl_userid').alias('tnc_giftcards_userid'),
                    F.col('measure_val').alias('tnc_accepted_at_giftcards'))
 
        # AGGR: last_login_at_grocery
        df_tnc_login_grocery = df_aggr.filter(
            (F.col("measure_nm") == "LAST_LOGIN_DATE") & (F.col("channel_cd") == "GROCERY")) \
            .select(F.col('singl_profl_userid').alias('tnc_login_grocery_userid'),
                    F.col('measure_val').alias('last_login_at_grocery'))
 
        # AGGR: last_login_at_sng_kiosk
        df_tnc_login_kiosk = df_aggr.filter(
            (F.col("measure_nm") == "LAST_LOGIN_DATE") & (F.col("channel_cd") == "SNGKIOSK")) \
            .select(F.col('singl_profl_userid').alias('tnc_login_kiosk_userid'),
                    F.col('measure_val').alias('last_login_at_sng_kiosk'))
 
        # AGGR: last_login_at_sng_mobile
        df_tnc_login_mobile = df_aggr.filter(
            (F.col("measure_nm") == "LAST_LOGIN_DATE") & (F.col("channel_cd") == "SNGMOBILE")) \
            .select(F.col('singl_profl_userid').alias('tnc_login_mobile_userid'),
                    F.col('measure_val').alias('last_login_at_sng_mobile'))
 
        # AGGR: last_login_at_george
        df_tnc_login_george = df_aggr.filter(
            (F.col("measure_nm") == "LAST_LOGIN_DATE") & (F.col("channel_cd") == "GEORGE")) \
            .select(F.col('singl_profl_userid').alias('tnc_login_george_userid'),
                    F.col('measure_val').alias('last_login_at_george'))

 
        # AGGR: last_login_at_asda
        df_tnc_login_asda = df_aggr.filter(
            (F.col("measure_nm") == "LAST_LOGIN_DATE") & (F.col("channel_cd") == "ASDA")) \
            .select(F.col('singl_profl_userid').alias('tnc_login_asda_userid'),
                    F.col('measure_val').alias('last_login_at_asda'))
 
        # AGGR: last_login_at_btc
        df_tnc_login_btc = df_aggr.filter(
            (F.col("measure_nm") == "LAST_LOGIN_DATE") & (F.col("channel_cd") == "BTC")) \
            .select(F.col('singl_profl_userid').alias('tnc_login_btc_userid'))
                   # F.col('measure_val').alias('last_login_at_btc'))
        df_tnc_login_btc = df_tnc_login_btc.withColumn("last_login_at_btc", F.lit(""))
 
        # AGGR: last_login_at_giftcards
        df_tnc_login_giftcards = df_aggr.filter(
            (F.col("measure_nm") == "LAST_LOGIN_DATE") & (F.col("channel_cd") == "GIFTCARDS")) \
            .select(F.col('singl_profl_userid').alias('tnc_login_giftcards_userid'),
                    F.col('measure_val').alias('last_login_at_giftcards'))
 
        # AGGR: last_login_at_loyalty
        df_tnc_login_loyalty = df_aggr.filter(
            (F.col("measure_nm") == "LAST_LOGIN_DATE") & (F.col("channel_cd") == "LOYALTY")) \
            .select(F.col('singl_profl_userid').alias('tnc_login_loyalty_userid'),
                    F.col('measure_val').alias('last_login_at_loyalty'))
 
 
        # AGGR: tnc_accepted_at_asdamobile
        df_tnc_asdamble = df_aggr.filter(
            (F.col("measure_nm") == "TNC_ACCEPTED_DATE") & (F.col("channel_cd") == "ssomobile")) \
            .select(F.col('singl_profl_userid').alias('tnc_asdamble_userid'),
                    F.col('measure_val').alias('tnc_accepted_at_asdamobile'))
       # Join all Aggregates to the output Data Set
 
        df_output = df_sp.join(df_tnc_lty, df_sp.singl_profl_id == df_tnc_lty.tnc_lty_singl_profl_userid, how="LEFT") \
            .join(df_reg_chn, df_sp.singl_profl_id == df_reg_chn.reg_chn_singl_profl_userid, how="LEFT") \
            .join(df_tnc_gcy, df_sp.singl_profl_id == df_tnc_gcy.tnc_gcy_userid, how="LEFT") \
            .join(df_tnc_kiosk, df_sp.singl_profl_id == df_tnc_kiosk.tnc_kiosk_userid, how="LEFT") \
            .join(df_tnc_mobile, df_sp.singl_profl_id == df_tnc_mobile.tnc_mobile_userid, how="LEFT") \
            .join(df_tnc_george, df_sp.singl_profl_id == df_tnc_george.tnc_george_userid, how="LEFT") \
            .join(df_tnc_btc, df_sp.singl_profl_id == df_tnc_btc.tnc_btc_userid, how="LEFT") \
            .join(df_tnc_giftcards, df_sp.singl_profl_id == df_tnc_giftcards.tnc_giftcards_userid, how="LEFT") \
            .join(df_tnc_login_grocery, df_sp.singl_profl_id == df_tnc_login_grocery.tnc_login_grocery_userid, how="LEFT") \
            .join(df_tnc_login_kiosk, df_sp.singl_profl_id == df_tnc_login_kiosk.tnc_login_kiosk_userid, how="LEFT") \
            .join(df_tnc_login_mobile, df_sp.singl_profl_id == df_tnc_login_mobile.tnc_login_mobile_userid, how="LEFT") \
            .join(df_tnc_login_george, df_sp.singl_profl_id == df_tnc_login_george.tnc_login_george_userid, how="LEFT") \
            .join(df_tnc_login_asda, df_sp.singl_profl_id == df_tnc_login_asda.tnc_login_asda_userid, how="LEFT") \
            .join(df_tnc_login_btc, df_sp.singl_profl_id == df_tnc_login_btc.tnc_login_btc_userid, how="LEFT") \
            .join(df_tnc_login_giftcards, df_sp.singl_profl_id == df_tnc_login_giftcards.tnc_login_giftcards_userid, how="LEFT") \
            .join(df_tnc_login_loyalty, df_sp.singl_profl_id == df_tnc_login_loyalty.tnc_login_loyalty_userid, how="LEFT") \
            .join(df_ghs_user, df_sp.singl_profl_id == df_ghs_user.user_singl_profl_id, how="LEFT") \
            .join(df_loyalty_acct, df_sp.singl_profl_id == df_loyalty_acct.user_loyalty_singl_profl_id, how="LEFT") \
            .join(df_tnc_asdamble, df_sp.singl_profl_id == df_tnc_asdamble.tnc_asdamble_userid, how="LEFT")
 
        df_output = df_output.withColumn("tnc_accepted_at_sng",
                                          F.when(
                                              df_output.tnc_accepted_at_sng_kiosk < df_output.tnc_accepted_at_sng_mobile,
                                              df_output.tnc_accepted_at_sng_kiosk).otherwise(
                                                    df_output.tnc_accepted_at_sng_mobile))

       #temp solution to check test accounts
        df_output = df_output.withColumn("test_account_ind",
                                        F.when(df_output.email.like('%@asda1%'), 'Y')
                                         .when(df_output.email.like('%[_]automation%'), 'Y')
                                         .when(df_output.email.like('createnew%'), 'Y')
                                         .when(df_output.email.like('mobile_auto%'), 'Y')
                                         .when(df_output.email.like('rishi2019%'), 'Y')
                                         .when(df_output.email.like('qa[_]%'), 'Y')
                                         .when(df_output.email.like('%qaprod%'), 'Y')
                                         .when(df_output.email.like('%@devmail%'), 'Y')
                                         .when(df_output.email.like('%@asda1%'), 'Y')
                                         .when(df_output.email.like('%@asda2%'), 'Y')
                                         .when(df_output.email.like('%@user.com'), 'Y')
                                         .when(df_output.email.like('%sngtest%'), 'Y')
                                         .when(df_output.email.like('%@test.com'), 'Y')
                                         .when(df_output.email.like('%@jmeter.com'), 'Y')
                                         .when(df_output.email.like('%@keynote.doo'), 'Y')
                                         .when(df_output.email.like('%@sptest.com'), 'Y')
                                         .when(df_output.email.like('%@spother.com'), 'Y')
                                         .when(df_output.email.like('%sng.com'), 'Y')
                                         .when(df_output.email.like('%asif.com'), 'Y')
                                         .when(df_output.email.like('%test4.com'), 'Y')
                                         .when(df_output.email.like('%tnccheck%'), 'Y')
                                         .when(df_output.email.like('%prodcheck%'), 'Y')
                                         .when(df_output.email.like('%bsahoo%'), 'Y')
                                         .when(df_output.email.like('%asda.com'), 'Y')
                                         .when(df_output.email.like('%asdatest.com'), 'Y')
                                         .when(df_output.email.like('%keynote%'), 'Y')
                                         .when(df_output.email.like('%checkoutopt%'), 'Y')
                                         .when(df_output.email.like('dpmigrationtest%'), 'Y')
                                         .when(df_output.email.like('%qa_spuser%'), 'Y')
                                         .when(df_output.email.like('%scanandgoqbust'), 'Y')
                                         .when(df_output.email.like('%perftest.com'), 'Y')
                                         .when(df_output.email.like('%asdatest%'), 'Y')
                                         .when(df_output.first_nm.like('TestFN'), 'Y')
                                         .when(df_output.first_nm.like('Automation%'), 'Y')
                                                                                .otherwise('N')
                                         )
        
        df_output = df_output.distinct()

        df_output.select('singl_profl_id', 'unified_cust_id', 'atg_customer_id', 'scndry_login_id', 'account_status',
                     'prefix', 'first_nm', 
                     'last_nm', 'email', 'guest_ind', 'registration_date', 'registration_channel', 'date_of_birth',
                     'suspend_status', 'suspend_reason', 'suspend_ts',
                     'tnc_accepted_at_loyalty', 'tnc_accepted_at_asdamobile', 'tnc_lty_singl_profl_userid',
                     'tnc_accepted_at_grocery', 'tnc_accepted_at_sng', 'tnc_accepted_at_sng_kiosk',
                     'tnc_accepted_at_sng_mobile',
                     'tnc_accepted_at_george', 'tnc_accepted_at_btc', 'tnc_accepted_at_giftcards',
                     'last_login_at_grocery', 'last_login_at_sng_kiosk', 'last_login_at_sng_mobile',
                     'last_login_at_george', 'last_login_at_asda', 'last_login_at_btc', 'last_login_at_giftcards',
                     'last_login_at_loyalty', 'upd_ts', 'test_account_ind', 'wallet_id') \
        .write \
        .format("delta") \
        .mode("overwrite") \
        .save(self.target_table)
 
        print("************** SPARK JOB complete****************")
 
 
aa = singl_profl_customer()
aa.run()



# COMMAND ----------

dcust = spark.read.format("delta").load("/mnt/eim/business/internal/infoMart/dimensions/dim_customer_v2/")
dcust.createOrReplaceTempView("dcust")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from dcust limit 500 

# COMMAND ----------

# MAGIC %sql
# MAGIC select account_status from dcust group by account_status

# COMMAND ----------

# MAGIC %sql
# MAGIC select suspend_reason from dcust group by suspend_reason

# COMMAND ----------

spc = spark.read.format("delta").load("/mnt/eim/business/internal/ce/odl/cdd_odl_singl_profl_customer")
spc.createOrReplaceTempView("spc")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from spc limit 500

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*), count(distinct unified_cust_id), count(unified_cust_id) from spc

# COMMAND ----------

# MAGIC %sql
# MAGIC select unified_cust_id, count(distinct singl_profl_id) from spc group by unified_cust_id having count(singl_profl_id) >= 2

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from spc where unified_cust_id = 'U-9999999999994640630'