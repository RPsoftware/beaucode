# Databricks notebook source
# MAGIC %run /scripts/genericInfoMartModules/genericModules/genericFunctions

# COMMAND ----------

# Importing necessary libraries
import pyspark.sql.functions as F
import datetime as dt
import pyspark.sql.types
from pyspark.sql.functions import date_format
from pyspark.sql.types import IntegerType
from dateutil.relativedelta import *

# COMMAND ----------

class customerBasket:
    def __init__(self):
        """
        Assigning Variable from config file
        """
        # Target Table
        self.targetPath = "/mnt/eim/business/internal/ce/odl/cdd_odl_customer_basket"
     
        # Src Tables
        self.u_customer = gf.loadDeltaFile("/mnt/eim/business/internal/ce/raw/cdd_raw_unified_customer")
        self.u_customer.createOrReplaceTempView("cust")

        #bring in transaction_ids
        self.transaction_ids = gf.loadDeltaFile("/mnt/enh/business/internal/iddi/rdl/gb_customer_data_domain_odl/cdd_odl_transaction_ids") 
        self.transaction_ids.createOrReplaceTempView("tids")
  
        self.rundate = dt.datetime.now() - relativedelta(months=36)
        self.highwatermark = self.rundate.strftime("%Y-%m-%d")
        print(self.highwatermark)

    def run(self):

        # Ingest data from hive tables and store as df for later transformation and joins
        cust_df = spark.sql("SELECT distinct source_system_id_2, customerid, source FROM cust ")

        ti_df = spark.sql('''SELECT basket_id, store_nbr, visit_dt, visit_nbr, trans_type, channel_id, ghs_order_id, sng_cart_id, lead_xref, lead_token_id, singl_profl_id, wallet_id
        FROM tids 
        WHERE non_scan_visit_ind = '0' and visit_dt >= '{}' '''.format(self.highwatermark))
        
        min_date = ti_df.agg(F.min('visit_dt')).collect()[0][0]
        max_date = ti_df.agg(F.max('visit_dt')).collect()[0][0]

        print("min date in ti_df = ", min_date)
        print("max date in ti_df = ", max_date)

        channels = [2,3]

        ti_df = ti_df.withColumn("cip_rptg_ind", \
                                    F.when((F.col('channel_id') == 1) & (F.col('lead_xref').isNull()), 0)\
                                        .when((F.col('channel_id').isin(channels)) & (F.col('singl_profl_id').isNull()) & (F.col('lead_xref').isNull()), 0).otherwise(1))
        ti_df.repartition('visit_dt')

        print("number of rows in ti_df = ", ti_df.count())


		# split cust_df into source = 'sp' and source = 'store'
        uct_sp_df = cust_df.filter(F.col('source') == ('sp')).select('source_system_id_2', 'customerid')
        print("number of rows in uct_sp_df where source is sp = ", uct_sp_df.count())

        uct_store_df = cust_df.filter(F.col('source') == ('store')).select('source_system_id_2', 'customerid')
        print("number of rows in uct_store_df where source is store = ", uct_store_df.count())

        # Split ti_df into channel_id 1 AND channel_id 3 where SPID IS NULL / channel_id = 2 AND channel_id = 3 WHERE SPID IS NOT NULL
        ti_1_df = ti_df.filter((F.col('channel_id') == 1) |  \
                                ((F.col('channel_id') == 3) & (F.col('singl_profl_id').isNull())) | \
                                ((F.col('channel_id') == 2) & (F.col('singl_profl_id').isNull())))
        ti_1_df = ti_1_df.repartition('visit_dt')

        ti_23_df = ti_df.filter(((F.col('channel_id') == 2) & (F.col('singl_profl_id').isNotNull())) | \
                                ((F.col('channel_id') == 3) & (F.col('singl_profl_id').isNotNull())))
        ti_23_df = ti_23_df.repartition('visit_dt')

        # CALL FUNCTIONS
        cid_1_df = self.getCust1(ti_1_df, uct_store_df)
        cid_23_df = self.getCust2_3(ti_23_df, uct_sp_df)
        cb_df = self.getCustomerBasket(cid_1_df, cid_23_df) # merge results of two tables above

        print("number of rows in final df cb_df = ", cb_df.count())

        # WRITE TO TABLE
        #spark.conf.set("spark.sql.shuffle.partitions", 1500)
        cb_df = cb_df.distinct().repartition("visit_mth")
        cb_df.write.mode("overwrite").option("overwriteSchema", "true").format("delta").save(self.targetPath)

    @staticmethod
    def getCust1 (ti_1_df, uct_store_df):

        cid_1_df = ti_1_df.join(uct_store_df, on=[(ti_1_df.lead_token_id == uct_store_df.source_system_id_2)], how = 'LEFT')
        cid_1_df = cid_1_df.withColumn('unified_cust_id', F.col('customerid')).drop(cid_1_df.source_system_id_2)\
        .select('unified_cust_id','basket_id', 'store_nbr','visit_dt','visit_nbr', 'trans_type', 'channel_id','ghs_order_id', 'sng_cart_id', 'wallet_id', 'lead_xref', 'lead_token_id', 'cip_rptg_ind')
        cid_1_df = cid_1_df.repartition('visit_dt')
        return (cid_1_df)

    @staticmethod
    def getCust2_3 (ti_23_df, uct_sp_df):

        cid_23_df = ti_23_df.join(uct_sp_df, on=[(ti_23_df.singl_profl_id == uct_sp_df.source_system_id_2)], how='LEFT')
        cid_23_df = cid_23_df.withColumn('unified_cust_id', F.col('customerid')).drop(cid_23_df.source_system_id_2)\
        .select('unified_cust_id','basket_id', 'store_nbr','visit_dt','visit_nbr', 'trans_type','channel_id','ghs_order_id', 'sng_cart_id', 'wallet_id', 'lead_xref', 'lead_token_id', 'cip_rptg_ind')
        cid_23_df = cid_23_df.repartition('visit_dt')
        return(cid_23_df)
		
    @staticmethod
    def getCustomerBasket (cid_23_df, cid_1_df):

        cb_df = cid_1_df.union(cid_23_df)\
        .select('unified_cust_id','basket_id', 'store_nbr','visit_dt','visit_nbr', 'trans_type','channel_id','ghs_order_id', 'sng_cart_id', 'wallet_id', 'lead_xref', 'lead_token_id', 'cip_rptg_ind')
        cb_df = cb_df.withColumn('visit_mth', date_format(cb_df.visit_dt, 'yyyyMM').cast(IntegerType()))
        cb_df.dropDuplicates()
        return (cb_df)

ts = customerBasket()
ts.run()	


# COMMAND ----------

cb = spark.read.format("delta").load("/mnt/eim/business/internal/ce/odl/cdd_odl_customer_basket")
cb.createOrReplaceTempView("cb")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- select count(*) from cb where unified_cust_id is not null --1,721,630,818
# MAGIC -- select count(*) from cb -- 2,610,156,799
# MAGIC -- select trans_type, count(basket_id) from cb group by trans_type
# MAGIC -- trans_type	count(basket_id)
# MAGIC -- S	          2560349434
# MAGIC -- R	          49807365
# MAGIC
# MAGIC -- select count(basket_id), count(unified_cust_id), count(distinct unified_cust_id) 
# MAGIC select visit_dt, count(basket_id), count(unified_cust_id), count(distinct unified_cust_id)
# MAGIC from cb 
# MAGIC where visit_dt >= '2021-08-02' and visit_dt <='2024-08-01'
# MAGIC group by visit_dt
# MAGIC order by visit_dt
# MAGIC

# COMMAND ----------

tids = spark.read.format("delta").load("/mnt/stg/business/internal/iddi/rdl/gb_customer_data_domain_odl/cdd_odl_transaction_ids")
tids.createOrReplaceTempView("tids")


# COMMAND ----------

# MAGIC %sql
# MAGIC --select channel_id from tids group by channel_id
# MAGIC
# MAGIC select * from tids where basket_id in (
# MAGIC   '202407084419419004794'
# MAGIC ) 
# MAGIC -- is this in old world trans ids? does it need to be in new co?

# COMMAND ----------

# MAGIC %sql
# MAGIC select visit_dt, count(basket_id)
# MAGIC from tids 
# MAGIC where visit_dt >='2021-07-31' and visit_dt <='2024-07-28' and non_scan_visit_ind = 0 
# MAGIC group by visit_dt
# MAGIC order by visit_dt
# MAGIC