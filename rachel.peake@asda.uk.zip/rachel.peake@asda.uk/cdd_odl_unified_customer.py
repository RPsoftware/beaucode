# Databricks notebook source
# MAGIC %run /scripts/genericInfoMartModules/genericModules/genericFunctions

# COMMAND ----------

import pyspark.sql.functions as F

# COMMAND ----------

class customerInform:
 
    def __init__(self):
        """
        Assigning Variable from config file
        """
        
        self.targetPath = "/mnt/eim/business/internal/ce/odl/cdd_odl_unified_customer"

        self.singl_profl_table = gf.loadDeltaFile("/mnt/enh/business/confidential/iddi/rdl/gb_customer_data_domain_secured_odl/cdd_odl_singl_profl_customer")
        self.singl_profl_table.createOrReplaceTempView('singl_profl_view') # required for channel indicators

        self.raw_uc = spark.read.format("delta").load("/mnt/eim/business/internal/ce/raw/cdd_raw_unified_customer")
        self.sources = ['sp', 'store']
        self.ucid_latest = (self.raw_uc
                            .select(F.col("source_system_id"), F.col("source"), F.col("customerid"), F.col("version"), F.col("version_date"))
                            .filter(F.col("source").isin(self.sources))).repartition("version_date")

        # Get latest version of customerid
        self.latest_version = self.ucid_latest.agg(F.max('version')).collect()[0][0]
        self.filtered_uc = self.ucid_latest.where(self.ucid_latest.version == self.latest_version)
        self.filtered_uc.createOrReplaceTempView("filtered_uc")
        print("count of ucids before join: ", self.filtered_uc.count())

        self.dim_cust = spark.read.format("delta").load("/mnt/eim/business/internal/infoMart/dimensions/dim_customer_v2/")
        self.dim_cust.createOrReplaceTempView("dim_cust")

        self.cust_ucid = spark.sql("""select uc.customerid as unified_cust_id, uc.version, uc.source, uc.source_system_id, dc.* 
                                   from filtered_uc uc
                                   left join dim_cust dc
                                   on uc.source_system_id = dc.bk_singl_profl_id """)
        self.cust_ucid.createOrReplaceTempView("cust_ucid")
        print("count of ucids before join: ", self.cust_ucid.count())
        
        self.cip_activity_table = gf.loadDeltaFile("/mnt/enh/business/internal/iddi/rdl/gb_customer_data_domain_raw/cdd_raw_cip_cust_activity") #bring in customer activity flag 
        self.cip_activity_table.createOrReplaceTempView("cip_activity")
        
        self.transaction_ids_table = gf.loadDeltaFile("/mnt/enh/business/internal/iddi/rdl/gb_customer_data_domain_odl/cdd_odl_transaction_ids") #bring in transaction_ids
        self.transaction_ids_table.createOrReplaceTempView("trans_ids")
        
 
    def run(self):
        print("****************Execution Start****************")
 
        #get distinct list of UCIDs from raw_unified_customer_table 
        df_unified_customer_version = self.cust_ucid.select(F.col('unified_cust_id'), F.col('version')).distinct()
        df_unified_customer_version.createOrReplaceTempView('unified_customer_view')
 
        df_unified_customer_source = spark.sql("SELECT * FROM cust_ucid WHERE source = 'store'")
        df_unified_customer_source = df_unified_customer_source.select(F.col('unified_cust_id'),F.col('source_system_id')).distinct()

 
        #fetching registration channel based on earliest registration date
        df_reg = spark.sql('''select unified_cust_id, registration_channel
                      from
                        (select unified_cust_id , registration_channel
                        , ROW_NUMBER() over (partition by unified_cust_id order by registration_date asc) rn
                            from cust_ucid
                            ) reg_channel
                            where rn = 1 and registration_channel is not null''')
        df_reg.createOrReplaceTempView('reg_view')
 
        df_cust_ucid = spark.sql('''Select     unified_cust_id
                                               ,bk_singl_profl_id as singl_profl_id
                                               ,registration_date
                                               ,hk_crm_customer as crm_id
                                                from
                                                    (SELECT  unified_cust_id
                                                            ,bk_singl_profl_id
                                                            ,registration_date
                                                            ,hk_crm_customer
                                                            ,row_number() over (partition by unified_cust_id order by registration_date asc)rn
                                                    FROM cust_ucid
                                                    )cust_ucid
                                                where rn=1 ''')
        df_cust_ucid.createOrReplaceTempView('cust_ucid_view')
 
        df_trans_ids = spark.sql('SELECT lead_token_id fROM trans_ids WHERE channel_id = 1')
 
        df_source_view = df_unified_customer_source.join(df_trans_ids, on=[df_unified_customer_source.source_system_id == df_trans_ids.lead_token_id], how='LEFT')
        df_source_view = df_source_view.withColumn('in_store', F.when(F.col('lead_token_id') == F.col('source_system_id'), 1).otherwise(0))
        df_source_view = df_source_view.select('unified_cust_id', 'in_store').drop(df_source_view.lead_token_id)
        df_in_store_ind = df_source_view.groupBy('unified_cust_id').agg(F.max('in_store').alias('in_store_ind'))
        df_in_store_ind.createOrReplaceTempView('in_store_ind')
 
        result_query = '''SELECT u.unified_cust_id
                            ,c.registration_date
                            ,reg.registration_channel
                            ,cip.is_active_cip
                            
                            ,CASE WHEN S.in_store_ind = 1 THEN 1 ELSE 0 END as in_store_ind
                            ,CASE WHEN C.unified_cust_id is not null then 'Y' else 'N' END as single_profile_ind
                            ,CASE WHEN crm_id is not null then 'Y' ELSE 'N' end as crm_id_ind 
                            ,CASE WHEN sng.unified_cust_id is not null and
                             sng.tnc_accepted_at_grocery is not null then 'Y' else 'N' END as channel_grocery_ind
                            ,CASE WHEN sng.unified_cust_id is not null and
                             (sng.tnc_accepted_at_sng_kiosk is not null or sng.tnc_accepted_at_sng_mobile is not null)
                              then 'Y' else 'N' END as channel_sng_ind
                            ,CASE WHEN sng.unified_cust_id is not null and
                             sng.tnc_accepted_at_george is not null then 'Y' else 'N' END as channel_george_ind
                            ,CASE WHEN sng.unified_cust_id is not null and
                             sng.tnc_accepted_at_giftcards is not null then 'Y' else 'N' END as channel_giftcards_ind
                            ,CASE WHEN sng.unified_cust_id is not null and
                             sng.tnc_accepted_at_loyalty is not null then 'Y' else 'N' END as channel_loyalty_ind
                            FROM unified_customer_view u
                            LEFT OUTER JOIN cust_ucid_view c ON u.unified_cust_id = c.unified_cust_id
                            LEFT OUTER JOIN in_store_ind S ON u.unified_cust_id = S.unified_cust_id
                            LEFT OUTER JOIN singl_profl_view sng ON c.singl_profl_id = sng.singl_profl_id
                            and sng.unified_cust_id = c.unified_cust_id
                            LEFT OUTER JOIN reg_view reg on c.unified_cust_id = reg.unified_cust_id
                            LEFT OUTER JOIN cip_activity cip on u.unified_cust_id = cip.unified_cust_id'''
 
        write_df = spark.sql(result_query)
        write_df = write_df.distinct()
        write_df.write.mode("overwrite").option("overwriteSchema", "true").format("delta").save(self.targetPath)
 
aa = customerInform()
aa.run()



# COMMAND ----------

df = spark.read.format("delta").load("/mnt/eim/business/internal/ce/odl/cdd_odl_unified_customer")
df.createOrReplaceTempView("uc")
cip_activity_table = spark.read.format("delta").load("/mnt/enh/business/internal/iddi/rdl/gb_customer_data_domain_raw/cdd_raw_cip_cust_activity") #bring in customer activity flag 
cip_activity_table.createOrReplaceTempView("cip_activity")

# COMMAND ----------

# MAGIC %sql 
# MAGIC select crm_id_ind, count(*) from uc group by crm_id_ind

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from cip_activity limit 500