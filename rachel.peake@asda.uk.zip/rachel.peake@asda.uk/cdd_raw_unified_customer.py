# Databricks notebook source
#
# Customer Matching Engine (CME 1.0)
#

#Install additional libraries
%pip install pycryptodome

# COMMAND ----------

# MAGIC %run /scripts/genericInfoMartModules/genericModules/dimProcessing

# COMMAND ----------

# MAGIC %run /scripts/genericInfoMartModules/genericModules/genericFunctions
# MAGIC

# COMMAND ----------

# Importing necessary libraries
import base64
from Crypto.Cipher import AES
from pyspark.sql.types import StringType
import re
import os
import pyspark.sql.functions as F
from Crypto.Util.Padding import pad


# COMMAND ----------

#from pyspark.dbutils import DBUtils dbutils = DBUtils(spark)  dbutils.fs.mounts()

# COMMAND ----------

import pyspark.sql.functions as F
from pyspark.sql.types import StringType, DecimalType, LongType, DateType
from pyspark.sql.window import Window
import re

class matchingEngine:
    
    def __init__(self): 

        #spark settings 
        #spark.conf.set("spark.sql.parquet.enable,summary-metadata","false") #Added for performance improvement while writing parquet file
        spark.conf.set("spark.sql.parquet.enableVectorizedReader","false") #Stopping the automatic conversion in double,decimal datatye to Binary
        
        #source path for data in rdl storage (enrich layer)
        #self.sourcePath = "/mnt/enh/business/"
        self.sourcePath = "/mnt/stg/business/"
        
        #data
        self.cust = gf.loadDeltaFile(self.sourcePath + "confidential/iddi/rdl/gb_customer_secured_dl_tables/cust")   #bring in cust data
        self.custCard = gf.loadDeltaFile(self.sourcePath + "confidential/iddi/rdl/gb_customer_secured_dl_tables/cust_card/") #bring in cust_card data
        self.stor = gf.loadDeltaFile(self.sourcePath + "confidential/iddi/rdl/gb_mb_store_secured_dl_tables/store_visit_tender/")  #bring in store_visit_tender data 
        self.custCntct = gf.loadDeltaFile(self.sourcePath + "confidential/iddi/rdl/gb_customer_secured_dl_tables/cust_cntct") #bring in cust_cntct
        self.custAddr = gf.loadDeltaFile(self.sourcePath + "confidential/iddi/rdl/gb_customer_secured_dl_tables/cust_addr") #bring in cust_addr
        self.transaction_ids = gf.loadDeltaFile("/mnt/enh/business/internal/iddi/rdl/gb_customer_data_domain_odl/cdd_odl_transaction_ids") #bring in transaction_ids
        self.dim_customer = gf.loadDeltaFile("/mnt/eim/business/internal/infoMart/dimensions/dim_customer_v2/") #bring in dim_customer data
 
        #variables
        #self.columns_to_check = ['ref_id']
        self.columns_to_check = ['customerid', 'source_system_id', 'title', 'first_name', 'middle_name', 'last_name', 'email_id', 'phone_nbr', 'pihash', 'xref', 'guest_order_ind', 'billing_first_name', 'billing_last_name', 'billing_address1', 'billing_address2', 'billing_address3', 'billing_address4', 'billing_address5', 'billing_address6', 'billing_city', 'billing_county', 'billing_zip_Cd', 'billing_state', 'billing_country', 'billing_address', 'latitude', 'longitude', 'blacklist', 'cbb_seen', 'version', 'source', 'ingestts', 
                                 ]

        self.email_id_column_patterns = ['%@asda1%', '%[_]automation%', 'createnew%', 'mobile_auto%', 'rishi2019%', 'qa[_]%', '%qaprod%', '%@devmail%', '%@asda1%', '%@asda2%', '%@user.com', '%sngtest%', '%@test.com', '%@jmeter.com', '%@keynote.doo', '%@sptest.com', '%@spother.com', '%sng.com', '%asif.com', '%test4.com', '%tnccheck%', '%prodcheck%', '%bsahoo%', '%asda.com', '%asdatest.com', '%keynote%', '%checkoutopt%', 'dpmigrationtest%', '%qa_spuser%', '%scanandgoqbust', '%perftest.com', '%asdatest%'
                                ]
        self.first_name_column_patterns = ['Automation%','TestFN']

        #set dates
        self.max_date = F.current_date()
        self.min_date = date_sub(self.max_date, 1096)

        #set env variables
        self.env = os.getenv('env')
        self.loc = 'uks'
        self.instance = '01'

        ## Key Vault variables
        self.dbScope = 'kv-sa-lnd-{}-{}-{}'.format(self.env,self.loc,self.instance)
        self.secretKey = 'dbr-spn'
        self.clientId = 'spn-AppId'
        self.master_key = dbutils.secrets.get(scope='kv-sa-lnd-{}-{}-{}'.format(self.env, self.loc, self.instance), key='customer-confidential')

        ## Target table variables 
        self.targetTable = "cdd_odl_unified_customer"
        self.targetPath = "/mnt/eim/business/internal/ce/raw/cdd_raw_unified_customer"
        self.partitionList = ["source"]
        #self.sk_key = "dim_unified_customer_sk"

#Function to replace blank values with null
    def replace_blank_with_null(self,df,columns_to_check):
        new_df = df.select([F.when(F.col(column) == '', None).otherwise(F.col(column)).alias(column) for column in columns_to_check])
        return new_df

#Function to filter out the test data before matching
    def filter_test_data(self,df, email_column,email_column_patterns,first_name_column,first_name_column_patterns):
        remaining_df = df
        email_condition = df[email_column].rlike('|'.join(email_column_patterns))
        first_name_condition = df[first_name_column].rlike('|'.join(first_name_column_patterns))
        matched_data = df.filter(email_condition | first_name_condition)
        remaining_df = remaining_df.subtract(matched_data)
        return matched_data, remaining_df

#Function to convert sql wildcard to python regular expression for removing test data since we are using python
    def sql_list_to_regex_list(self,sql_list):
        regex_exp_list = [re.sub(r"%",".*",expr) for expr in sql_list]
        regex_exp_list = [re.sub(r"_",".",expr) for expr in regex_exp_list]
        return regex_exp_list   


    def run(self):
        
        self.stor = self.stor.filter(F.col('visit_dt') > self.min_date)
        #stor_count_1 = self.stor.count()
    
        self.stor = (self.stor.select('acct_nbr', 'tndr_type_cd', 'upd_ts')
                     .filter(F.col('tndr_type_cd') == 8)
                     .withColumn('acct_nbr', F.trim(F.col('acct_nbr')))
                     .groupBy('acct_nbr').agg(F.max('upd_ts').alias('upd_ts')) 
                     .distinct())
        self.stor = self.replace_blank_with_null(self.stor,self.stor.columns)
        #stor_count_2 = self.stor.count()
                

        self.custCard = (self.custCard.select('pymt_token_txt', 'ref_id', 'gdpr_del_ind', 'cust_del_ind', 'singl_profl_id')
                         .filter((F.col('gdpr_del_ind')== 0) & (F.col('cust_del_ind') ==0) )
                         .withColumn('pymt_token_txt', F.trim(F.col('pymt_token_txt')))
                         .withColumn('ref_id', F.col('ref_id').cast(LongType()))
                         .distinct())       
        self.custCard = self.replace_blank_with_null(self.custCard,self.custCard.columns)

        self.cust.createOrReplaceTempView("cust")
        self.custCard.createOrReplaceTempView("custCard")
        self.stor.createOrReplaceTempView('stor')
        self.custCntct.createOrReplaceTempView("custCntct")
        self.custAddr.createOrReplaceTempView("custAddr")

        
        #spark sql joins
        sp="""select '' as customerid
                        ,cust.singl_profl_id as source_system_id 
                        ,lower(trim(cust.title_cd)) as title, lower(replace(replace(replace(trim(cust.first_nm),'-',''),'\"',''),'''','')) as first_name 
                        ,cust.mid_nm as middle_name
                        ,lower(replace(replace(replace(trim(cust.last_nm),'-',''),'\"',''),'''','')) As last_name 
                        ,lower(trim(cust.email_id)) as email_id 
                        ,COALESCE(trim(cntct.cntct_nm)
                        ,trim(cust.scndry_login_id)) as phone_nbr
                        ,trim(cr.pymt_token_txt) as pihash
                        ,trim(cr.ref_id) as xref
                        ,cust.guest_ind as guest_order_ind
                        ,lower(trim(adr.first_nm)) as billing_first_name,lower(trim(adr.last_nm)) as billing_last_name 
                        ,lower(trim(adr.addr_line_1_txt)) as billing_address1
                        ,lower(trim(adr.addr_line_2_txt)) as billing_address2 
                        ,lower(trim(adr.addr_line_3_txt)) as  billing_address3
                        ,'' as billing_address4
                        ,'' as billing_address5
                        ,'' as billing_address6 
                        ,lower(trim(adr.city_nm)) as billing_city
                        ,'' as billing_county
                        ,lower(trim(adr.post_cd)) as billing_zip_Cd
                        ,lower(trim(adr.st_nm)) as billing_state
                        ,lower(trim(adr.cntry_cd)) as billing_country
                        ,lower(trim(adr.fmt_addr_txt)) as billing_address
                        ,adr.lat_dgr as latitude
                        ,adr.long_dgr as longitude
                        ,'' as blacklist
                        ,'' as cbb_seen
                        ,'' as version
                        ,lower(cust.data_src_cd) as source
                        ,IFNULL((DATE_FORMAT(cust.ingest_ts,'yyyyMMdd')),999999) as ingestts 
                from (select singl_profl_id,title_cd,first_nm,last_nm,mid_nm,email_id,guest_ind,data_src_cd,ingest_ts, scndry_login_id
                        from cust where gdpr_del_ind=0 ) cust 
                left join (select cntct_nm,singl_profl_id 
                        from custCntct 
                        where cntct_type_nm ='PHONE' and gdpr_del_ind=0 and cust_del_ind=0) cntct 
                on cust.singl_profl_id=cntct.singl_profl_id 
                left join (select singl_profl_id,pymt_token_txt,ref_id 
                        from custCard 
                        ) cr 
                on cust.singl_profl_id=cr.singl_profl_id 
                left join (select singl_profl_id, first_nm, last_nm, addr_line_1_txt, addr_line_2_txt, addr_line_3_txt, city_nm, post_cd, st_nm, cntry_cd, fmt_addr_txt, lat_dgr, long_dgr 
                        from custAddr  
                        where gdpr_del_ind=0 and cust_del_ind=0 and (addr_usag_type_nm IS NULL or addr_usag_type_nm='shipTo')) adr
                on cust.singl_profl_id=adr.singl_profl_id """
      
        sp = spark.sql(sp).dropDuplicates()
        #sp.coalesce(1).write.format("csv").mode("overwrite").save('/mnt/raw/matchingEngine/gbTablesData/unifiedRawData/CME/spDF.csv')
 
        #create store data df
        storeExtract="""select '' as customerid
                                ,stor.acct_nbr as source_system_id
                                ,null as title
                                ,null as first_name
                                ,null as middle_name
                                ,null As last_name
                                ,null as email_id
                                ,null as phone_nbr
                                ,cr.pymt_token_txt as pihash
                                ,stor.acct_nbr as xref
                                ,null as guest_order_ind
                                ,null as billing_first_name
                                ,null as billing_last_name
                                ,null as billing_address1
                                ,null as billing_address2
                                ,null as  billing_address3
                                ,null as billing_address4
                                ,null as billing_address5
                                ,null as billing_address6
                                ,null as billing_city
                                ,null as billing_county
                                ,null as billing_zip_Cd
                                ,null as billing_state
                                ,null as billing_country
                                ,null as billing_address
                                ,null as latitude
                                ,null as longitude
                                ,null as blacklist
                                ,null as cbb_seen
                                ,null as version
                                ,'store' as source
                                ,IFNULL((DATE_FORMAT(upd_ts, 'yyyyMMdd')),999999) as partkey 
                        from (select acct_nbr,upd_ts 
                                from stor    
                                ) stor 
                        full outer join (select pymt_token_txt, ref_id 
                                        from custCard) cr 
                        on stor.acct_nbr = cr.ref_id """

        storeExtract = spark.sql(storeExtract).dropDuplicates()
        
        unionDF = sp.union(storeExtract)

        #Replacing blank values with null
        df_intData_trans = self.replace_blank_with_null(unionDF,unionDF.columns)
        #union_count = df_intData_trans.count()

        #test data removal to get the data frame free of unwanted test data
        email_id_column_patterns_formatted = self.sql_list_to_regex_list(self.email_id_column_patterns)
        first_name_column_patterns_formatted = self.sql_list_to_regex_list(self.first_name_column_patterns)
        
        test_data_frame, cleanDF = self.filter_test_data(df_intData_trans,'email_id',email_id_column_patterns_formatted,'first_name', first_name_column_patterns_formatted)
        
        #replacing the leading 0's in xref for a proper match / Changing Datatype of UCID from String to Long 
        df_intData = (cleanDF.withColumn('xref',F.regexp_replace(F.col('xref'),'^0+',''))
                      .withColumn("customerid",F.col("customerid").cast("long"))
                      )

        # Applying axiomatic rules
        window_spec_ordering = Window.orderBy("source")
        df = df_intData.withColumn("row_number",F.row_number().over(window_spec_ordering))
        max_id = "10000000000000000000"
        max_id = (F.lit(max_id)).cast(DecimalType(20, 0))
        df = df.withColumn("customerid",max_id-F.col("row_number").cast(DecimalType(20, 0)))
        df = df.drop("row_number")
        
        #Window specification for rules
        window_spec_0 = Window.partitionBy("source_system_id").orderBy(F.col('customerid').isNull().cast('int'))
        window_spec_1 = Window.partitionBy("first_name","last_name","email_id").orderBy(F.col('customerid').isNull().cast('int'))
        window_spec_2 = Window.partitionBy("first_name","last_name","phone_nbr").orderBy(F.col('customerid').isNull().cast('int'))
        window_spec_3 = Window.partitionBy("first_name","last_name","billing_address").orderBy(F.col('customerid').isNull().cast('int'))
        window_spec_4 = Window.partitionBy("first_name","last_name","xref").orderBy(F.col('customerid').isNull().cast('int'))
        window_spec_5 = Window.partitionBy("xref").orderBy(F.col('customerid').isNull().cast('int'))

        #Assign min unique id with each group
        df_w1 = df.withColumn("max_customerid",F.max("customerid").over(window_spec_0))
        df_w1 = df_w1.withColumn("customerid", F.when(F.col('source_system_id').isNotNull(),F.col("max_customerid")).otherwise(F.col('customerid'))).drop("max_customerid")

        df_w2 = df_w1.withColumn("max_customerid",F.max("customerid").over(window_spec_1))
        df_w2 = df_w2.withColumn("customerid", F.when((F.col('first_name').isNotNull()) & (F.col('last_name').isNotNull()) & (F.col('email_id').isNotNull()),F.col("max_customerid")).otherwise(F.col('customerid'))).drop("max_customerid")

        df_w3 = df_w2.withColumn("max_customerid",F.max("customerid").over(window_spec_2))
        df_w3 = df_w3.withColumn("customerid", F.when((F.col('first_name').isNotNull()) & (F.col('last_name').isNotNull()) & (F.col('phone_nbr').isNotNull()),F.col("max_customerid")).otherwise(F.col('customerid'))).drop("max_customerid")

        df_w4 = df_w3.withColumn("max_customerid",F.max("customerid").over(window_spec_3))
        df_w4 = df_w4.withColumn("customerid", F.when((F.col('first_name').isNotNull()) & (F.col('last_name').isNotNull()) & (F.col('billing_address').isNotNull()) & (~F.col('billing_address').startswith('dummy')) & (~F.col('billing_address').contains('dummy')),F.col("max_customerid")).otherwise(F.col('customerid'))).drop("max_customerid")

        df_w5 = df_w4.withColumn("max_customerid",F.max("customerid").over(window_spec_4))
        df_w5 = df_w5.withColumn("customerid", F.when((F.col('first_name').isNotNull()) & (F.col('last_name').isNotNull()) & (F.col('xref').isNotNull()),F.col("max_customerid")).otherwise(F.col('customerid'))).drop("max_customerid")

        res_df = df_w5.withColumn("max_customerid",F.max("customerid").over(window_spec_5))
        res_df = res_df.withColumn("customerid",F.when((F.col('xref').isNotNull()) & (F.col('source') == 'store'),F.col("max_customerid")).otherwise(F.col('customerid'))).drop("max_customerid")

        # Column attached to check the rule applied(Still in progress)
        final_df =res_df.withColumn("matched",F.when(((F.count("*").over(window_spec_1)>1) & F.col('customerid').isNotNull() & (F.col('first_name').isNotNull()) & (F.col('last_name').isNotNull()) & (F.col('email_id').isNotNull())),"R1").otherwise(None))

        final_df =final_df.withColumn("matched",F.when(((F.count("*").over(window_spec_2)>1) & F.col('customerid').isNotNull() & (F.col('first_name').isNotNull()) & (F.col('last_name').isNotNull()) & (F.col('phone_nbr').isNotNull())),F.when(final_df["matched"].isNull(),"R2").otherwise(F.concat(final_df["matched"],F.lit("R2")))))

        final_df =final_df.withColumn("matched",F.when(((F.count("*").over(window_spec_3)>1) & F.col('customerid').isNotNull() & (F.col('first_name').isNotNull()) & (F.col('last_name').isNotNull()) & (F.col('billing_address').isNotNull())),F.when(final_df["matched"].isNull(),"R3").otherwise(F.concat(final_df["matched"],F.lit("R3")))))

        final_df =final_df.withColumn("matched",F.when(((F.count("*").over(window_spec_4)>1) & F.col('customerid').isNotNull() & (F.col('first_name').isNotNull()) & (F.col('last_name').isNotNull()) & (F.col('xref').isNotNull())),F.when(final_df["matched"].isNull(),"R4").otherwise(F.concat(final_df["matched"],F.lit("R4")))))

        final_df =final_df.withColumn("matched",F.when(((F.count("*").over(window_spec_5)>1) & F.col('customerid').isNotNull() & (F.col('xref').isNotNull())),F.when(final_df["matched"].isNull(),"R5").otherwise(F.concat(final_df["matched"],F.lit("R5")))))

        final_df =final_df.withColumn("matched",F.when(((F.count("*").over(window_spec_0)>1) & F.col('customerid').isNotNull() & (F.col('source_system_id').isNotNull())),F.when(final_df["matched"].isNull(),"R0").otherwise(F.concat(final_df["matched"],F.lit("R0")))))

        final_df = final_df.withColumn("customerid", F.concat(F.lit('U-'),F.col("customerid").cast("string"))).withColumn("cbb_seen",F.date_format(F.current_timestamp(),"yyyy-MM-dd HH:mm:ss")).withColumn("version",F.date_format(F.current_timestamp(),"yyyyMMddHHmm"))
        
        #joining TRANSACTION_IDS to fetch worldline token id 
        trans_ids_filtered = self.transaction_ids.select("lead_xref", "lead_token_id")
        trans_ids_filtered = trans_ids_filtered.filter(F.length(trans_ids_filtered.lead_token_id) < 30) #filter to remove token_ids not required 

        #join unified_customer with transaction ids on xref = xref to fetch worldline token id.
        uc_ti_join = final_df.join(trans_ids_filtered, on=[trans_ids_filtered.lead_xref == final_df.xref], how="LEFT").drop(trans_ids_filtered.lead_xref)

        #join dim_customer to fetch crm id 
        dim_customer_filtered = self.dim_customer.select(F.col("bk_crm_customer_id"), F.col("bk_singl_profl_id"))
        
        uc_ti_cust = uc_ti_join.join(dim_customer_filtered, on=[dim_customer_filtered.bk_singl_profl_id == uc_ti_join.source_system_id], how='LEFT')
        
        write_df = uc_ti_cust.withColumn('source_system_id', (F.when((uc_ti_cust.lead_token_id.isNotNull()) & (uc_ti_cust.source_system_id == uc_ti_cust.xref), uc_ti_cust.lead_token_id).otherwise(uc_ti_cust.source_system_id)))
        
        write_df = (write_df
                        .select(F.col("customerid")
                        ,F.col('source_system_id')
                        ,F.col("title")
                        ,F.col("first_name")
                        ,F.col("middle_name")
                        ,F.col("last_name")
                        ,F.col("email_id")
                        ,F.col("phone_nbr")
                        ,F.col("pihash")
                        ,F.col("xref")
                        ,F.col("lead_token_id")
                        ,F.col("guest_order_ind")
                        ,F.col("billing_first_name")
                        ,F.col("billing_last_name")
                        ,F.col("billing_address1")
                        ,F.col("billing_address2")
                        ,F.col("billing_address3")
                        ,F.col("billing_address4")
                        ,F.col("billing_address5")
                        ,F.col("billing_address6")
                        ,F.col("billing_city")
                        ,F.col("billing_county")
                        ,F.col("billing_zip_Cd")
                        ,F.col("billing_state")
                        ,F.col("billing_country")
                        ,F.col("billing_address")
                        ,F.col("latitude")
                        ,F.col("longitude")
                        ,F.col("blacklist")
                        ,F.col("cbb_seen")
                        ,F.col("version")
                        ,F.col("source")
                        ,F.col("ingestts")
                        ,F.col("matched")
                        ,F.col("bk_crm_customer_id").alias("crm_id"))                
        )
        write_df = write_df.withColumn("version_date", F.substring(write_df.version, 1,8))
        
        write_count = write_df.count()

        #write out to storage account
        write_df = write_df.distinct().repartition('version_date')
        write_df.write.mode("overwrite").option("overwriteSchema", "true").format("delta").save(self.targetPath)
        
aa = matchingEngine()
aa.run()

# COMMAND ----------

duc = spark.read.format("delta").load("/mnt/eim/business/internal/ce/cdd_raw_unified_customer")
duc.createOrReplaceTempView("duc")

tids = spark.read.format("delta").load("/mnt/stg/business/internal/iddi/rdl/gb_customer_data_domain_odl/cdd_odl_transaction_ids")
tids.createOrReplaceTempView("tids")

dcust = spark.read.format("delta").load("/mnt/eim/business/internal/infoMart/dimensions/dim_customer_v2/")
dcust.createOrReplaceTempView("dcust")

cust_Addr =  spark.read.format("delta").load("/mnt/stg/business/confidential/iddi/rdl/gb_customer_secured_dl_tables/cust_addr")
cust_Addr.createOrReplaceTempView("addr") 

custCard = spark.read.format("delta").load("/mnt/stg/business/confidential/iddi/rdl/gb_customer_secured_dl_tables/cust_card/")
custCard.createOrReplaceTempView("custcard")

svt = spark.read.format("delta").load("/mnt/stg/business/confidential/iddi/rdl/gb_mb_store_secured_dl_tables/store_visit_tender/")
#df_write_txt = svt.select("acct_nbr")
#df_write_txt.write.mode("overwrite").format("text").save("/mnt/enh/business/confidential/iddi/rdl/gb_mb_store_secured_dl_tables/store_visit_tender.txt")
svt.createOrReplaceTempView("svt")

cust = spark.read.format("delta").load("/mnt/stg/business/confidential/iddi/rdl/gb_customer_secured_dl_tables/cust") 
cust.createOrReplaceTempView("cust")

first_df_base = spark.read.format("parquet").load("/mnt/raw/matchingEngine/gbTablesData/unifiedRawData/CME/unified_customer_table_L1.parquet")


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from duc where xref in (
# MAGIC '115735811198'
# MAGIC
# MAGIC )
# MAGIC '101490034390',
# MAGIC '120532880024',
# MAGIC '116421441449',
# MAGIC '117177140607',
# MAGIC '120270608843',
# MAGIC '115800535763',
# MAGIC '118465248862',
# MAGIC '120979379860',
# MAGIC '120152479719',
# MAGIC '121380502587',
# MAGIC '121947786723'
# MAGIC ) 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from cust where upper(channel_id) in ('GROCERY')

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(basket_id), count(singl_profl_id)
# MAGIC from tids 
# MAGIC where channel_id = 2 
# MAGIC and visit_dt >='2021-7-30' and visit_dt <='2024-07-28' 
# MAGIC and non_scan_visit_ind = 0 
# MAGIC --and singl_profl_id is not null 

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(basket_id) from tids where non_scan_visit_ind = 0 and visit_dt >='2021-08-01' and visit_dt <= '2024-08-01'

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*), count(distinct xref),  count(distinct crm_id), count(distinct source_system_id) from duc
# MAGIC
# MAGIC where xref is not null 

# COMMAND ----------

# MAGIC %sql 
# MAGIC select source_system_id from duc where xref is null and source_system_id is not null

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*), count(lead_xref), count(lead_token_id), count(distinct singl_profl_id) from tids

# COMMAND ----------

# MAGIC %md
# MAGIC This query highlights where xrefs are in transaction_ids table but not in dim_unified_customer, this also effects number of singl_profl_id matches to dim_customer_v2
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from ((
# MAGIC select distinct lead_xref from tids) og left join (
# MAGIC select distinct xref from duc ) jn on og.lead_xref = jn.xref ) a
# MAGIC where a.xref is null 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from tids where lead_xref in ('100728581792',
# MAGIC '103466098508',
# MAGIC '104653625616',
# MAGIC '105598981386',
# MAGIC '106650675619',
# MAGIC '10665509161',
# MAGIC '109408640083',
# MAGIC '110536590901',
# MAGIC '110571930178',
# MAGIC '110898776049',
# MAGIC '111068266050',
# MAGIC '111177230930',
# MAGIC '111423690093',
# MAGIC '111550439389',
# MAGIC '111585049518')

# COMMAND ----------

# MAGIC %md
# MAGIC this is to analyse data from store_visit_tender, when compared with the same query run in old world remio there are big gaps so have passed to Rama to rectify 

# COMMAND ----------

# MAGIC %sql
# MAGIC select visit_dt, count(distinct acct_nbr) 
# MAGIC from svt 
# MAGIC where tndr_type_cd = 8 and visit_dt > date_sub(current_date(), 1096)
# MAGIC group by visit_dt order by visit_dt asc
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC This query highlights any spids that exist in dim_customer_v2 but not in dim_unified_customer

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(bk_singl_profl_id), count(distinct bk_singl_profl_id)
# MAGIC from dcust

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(distinct bk_singl_profl_id)
# MAGIC , count(distinct bk_crm_customer_id)
# MAGIC , count(distinct singl_profl_id)
# MAGIC from dcust 
# MAGIC left join tids 
# MAGIC on tids.singl_profl_id = dcust.bk_singl_profl_id 
# MAGIC --and tids.lead_xref is not null
# MAGIC  

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct source_system_id from duc where length(source_system_id) > 35 limit 50 

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from duc where source_system_id = xref 